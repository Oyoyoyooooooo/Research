// Local dev server: serves public/ and the same /api routes as Vercel.
//   npm run dev            → http://localhost:5173
// Without DATABASE_URL, responses are saved to .data/responses.json.
// Dashboard team key defaults to "dev" (set TEAM_KEY to change).
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { handleSubmit, handleList } from '../lib/handlers.js';
import { storeFromEnv } from '../lib/store.js';
import { readBody, sendJson } from '../lib/http.js';

const root = resolve(fileURLToPath(new URL('../public', import.meta.url)));
const port = Number(process.argv[2] || process.env.PORT || 5173);
// "dev" key only for the local file store — never with a real database
const teamKey = process.env.TEAM_KEY || (process.env.DATABASE_URL ? '' : 'dev');
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon',
};

createServer(async (req, res) => {
  const path = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  try {
    if (path === '/api/submit') {
      if (req.method !== 'POST') return sendJson(res, { status: 405, body: { ok: false, error: 'method' } });
      return sendJson(res, await handleSubmit(await readBody(req), { store: await storeFromEnv() }));
    }
    if (path === '/api/responses') {
      if (req.method !== 'GET') return sendJson(res, { status: 405, body: { error: 'method' } });
      return sendJson(res, await handleList(req.headers, { store: await storeFromEnv(), teamKey }));
    }
    const file = normalize(join(root, path.endsWith('/') ? path + 'index.html' : path));
    if (file !== root && !file.startsWith(root + sep)) { res.writeHead(403).end(); return; }
    const body = await readFile(file);
    res.writeHead(200, { 'Content-Type': TYPES[extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' });
    res.end(body);
  } catch (err) {
    if (res.headersSent) return;
    if (path.startsWith('/api/')) { console.error(err?.message); sendJson(res, { status: 500, body: { ok: false, error: 'server' } }); return; }
    res.writeHead(404, { 'Content-Type': 'text/plain' }).end('not found');
  }
}).listen(port, () => {
  console.log(`เว็บแบบสำรวจ:  http://localhost:${port}/`);
  console.log(`Dashboard:     http://localhost:${port}/dashboard.html  (รหัสทีม: ${process.env.TEAM_KEY ? '(จาก TEAM_KEY)' : teamKey || 'ยังไม่ได้ตั้ง TEAM_KEY'})`);
  console.log(process.env.DATABASE_URL ? 'ฐานข้อมูล: Postgres (DATABASE_URL)' : 'ฐานข้อมูล: ไฟล์ .data/responses.json');
});
