// GET /api/responses — all responses for the team dashboard (needs header x-team-key = TEAM_KEY).
import { handleList } from '../lib/handlers.js';
import { storeFromEnv } from '../lib/store.js';
import { sendJson } from '../lib/http.js';

export default async function handler(req, res) {
  try {
    if (req.method !== 'GET') return sendJson(res, { status: 405, body: { error: 'method' } });
    const store = await storeFromEnv();
    sendJson(res, await handleList(req.headers, { store, teamKey: process.env.TEAM_KEY }));
  } catch (err) {
    console.error('list failed:', err?.message);
    if (!res.headersSent) sendJson(res, { status: 500, body: { ok: false, error: 'server' } });
  }
}
