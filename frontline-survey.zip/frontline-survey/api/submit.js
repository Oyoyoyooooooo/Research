// POST /api/submit — receives one survey response.
import { handleSubmit } from '../lib/handlers.js';
import { storeFromEnv } from '../lib/store.js';
import { readBody, sendJson } from '../lib/http.js';

export default async function handler(req, res) {
  try {
    if (req.method !== 'POST') return sendJson(res, { status: 405, body: { ok: false, error: 'method' } });
    const store = await storeFromEnv();
    sendJson(res, await handleSubmit(await readBody(req), { store }));
  } catch (err) {
    console.error('submit failed:', err?.message);
    if (!res.headersSent) sendJson(res, { status: 500, body: { ok: false, error: 'server' } });
  }
}
