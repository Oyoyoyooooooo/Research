import { QUESTIONS, getQuestion } from './questions.js';
import { pruneHidden } from './answers.js';

export const SYSTEM_COLUMNS = ['response_id', 'submitted_at', 'status', 'screened_at_q', 'duration_sec', 'is_test'];
export const TEXT_COLUMNS = ['q27_other_text', 'q33'];

const SYSTEM_LABELS = {
  response_id: 'รหัสคำตอบ (สุ่ม)', submitted_at: 'เวลาที่ส่ง', status: 'สถานะ (complete / screened_out)',
  screened_at_q: 'ถูกคัดออกที่ข้อ', duration_sec: 'เวลาที่ใช้ (วินาที)', is_test: 'ข้อมูลทดสอบ (1 = ใช่)',
};

export const qKey = num => `q${String(num).padStart(2, '0')}`;

let cached;
/** @returns {{key:string, q:number|null, kind:string, question:string, option:string, code?:string, row?:string}[]} */
export function buildColumns() {
  if (cached) return cached;
  const cols = SYSTEM_COLUMNS.map(key => ({ key, q: null, kind: 'system', question: SYSTEM_LABELS[key], option: '' }));
  for (const q of QUESTIONS) {
    const base = qKey(q.num);
    const question = `ข้อ ${q.num}. ${q.text}`;
    if (q.type === 'single' || q.type === 'text') {
      cols.push({ key: base, q: q.num, kind: q.type, question, option: '' });
    } else if (q.type === 'multi') {
      cols.push({ key: base, q: q.num, kind: 'multi_joined', question, option: '(คำตอบรวม คั่นด้วย , )' });
      for (const op of q.options) {
        cols.push({ key: `${base}_${op.code}`, q: q.num, kind: 'flag', question, option: op.label, code: op.code });
      }
      if (q.options.some(op => op.other)) {
        cols.push({ key: `${base}_other_text`, q: q.num, kind: 'other_text', question, option: 'ข้อความที่พิมพ์เอง (อื่นๆ)' });
      }
    } else if (q.type === 'grid') {
      for (const r of q.rows) cols.push({ key: `${base}_${r.code}`, q: q.num, kind: 'grid', question, option: r.label, row: r.code });
    }
  }
  cached = cols;
  return cols;
}

const labelOf = (opts, code) => opts.find(x => x.code === code)?.label ?? '';

export function toRow({ answers, status, screenedAtQ, startedAt, now, isTest, responseId }) {
  const a = pruneHidden(answers || {});
  const row = {};
  for (const c of buildColumns()) {
    row[c.key] = '';
    if (c.kind === 'system') continue;
    const q = getQuestion(`q${c.q}`);
    const v = a[q.id];
    switch (c.kind) {
      case 'single': if (v) row[c.key] = labelOf(q.options, v); break;
      case 'text': if (v) row[c.key] = String(v); break;
      case 'multi_joined': if (Array.isArray(v) && v.length) row[c.key] = v.map(code => labelOf(q.options, code)).join(', '); break;
      case 'flag': if (Array.isArray(v) && v.length) row[c.key] = v.includes(c.code) ? 1 : 0; break;
      case 'other_text': if (a[`${q.id}_other`]) row[c.key] = String(a[`${q.id}_other`]); break;
      case 'grid': if (v && v[c.row]) row[c.key] = labelOf(q.cols, v[c.row]); break;
    }
  }
  row.response_id = responseId;
  row.submitted_at = new Date(now).toISOString();
  row.status = status;
  row.screened_at_q = status === 'screened_out' ? screenedAtQ : '';
  row.duration_sec = Math.max(0, Math.round((now - startedAt) / 1000));
  row.is_test = isTest ? 1 : 0;
  return row;
}

export function codebook() {
  return buildColumns().map(c => ({ key: c.key, question: c.question, option: c.option }));
}

export function newResponseId() {
  const c = globalThis.crypto;
  if (c?.randomUUID) return c.randomUUID();
  return Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
}
