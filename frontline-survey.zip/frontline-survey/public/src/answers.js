import { QUESTIONS } from './questions.js';

export const MSG_REQUIRED = 'กรุณาเลือกคำตอบ';
export const MSG_GRID = 'กรุณาตอบให้ครบทุกแถว';

export function toggleMulti(question, current, code) {
  const value = Array.isArray(current) ? current : [];
  if (value.includes(code)) return { value: value.filter(c => c !== code), blocked: false };
  const opt = question.options.find(o => o.code === code);
  if (opt?.exclusive) return { value: [code], blocked: false };
  const exclusive = new Set(question.options.filter(o => o.exclusive).map(o => o.code));
  const kept = value.filter(c => !exclusive.has(c));
  if (question.max && kept.length >= question.max) return { value, blocked: true };
  return { value: [...kept, code], blocked: false };
}

export function validateAnswer(question, value, _answers) {
  if (!question.required) return { ok: true };
  switch (question.type) {
    case 'single':
      return value ? { ok: true } : { ok: false, message: MSG_REQUIRED };
    case 'multi':
      return Array.isArray(value) && value.length ? { ok: true } : { ok: false, message: MSG_REQUIRED };
    case 'grid': {
      const done = question.rows.every(r => value && value[r.code]);
      return done ? { ok: true } : { ok: false, message: MSG_GRID };
    }
    case 'text':
      return value && String(value).trim() ? { ok: true } : { ok: false, message: MSG_REQUIRED };
    default:
      return { ok: true };
  }
}

export function pruneHidden(answers) {
  const out = { ...answers };
  for (const q of QUESTIONS) {
    if (q.showIf && !q.showIf(out)) delete out[q.id];
  }
  if (!(Array.isArray(out.q27) && out.q27.includes('other'))) delete out.q27_other;
  return out;
}
