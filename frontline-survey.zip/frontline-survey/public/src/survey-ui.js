import { INTRO_TITLE, INTRO_SUBTITLE, THANKS_TEXT, getQuestion, sectionOf, splitHint } from './questions.js';
import { firstProblem, PAGES, pageIndexOf, pageProblems, pageScreenOut } from './flow.js';
import { toggleMulti } from './answers.js';
import { toRow, newResponseId } from './record.js';
import { store } from './storage.js';
import { submitRow } from './api.js';
import { API_URL } from '../config.js';
import { canSpeakThai, onVoicesReady, speak, stopSpeaking } from './tts.js';

/* ---------- icons (inline SVG, Lucide-style strokes) ---------- */
const svg = (d, extra = '') => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" ${extra}>${d}</svg>`;
const I = {
  check: svg('<path d="M20 6 9 17l-5-5"/>', 'stroke-width="3"'),
  dot: svg('<circle cx="12" cy="12" r="5" fill="currentColor" stroke="none"/>'),
  next: svg('<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>'),
  back: svg('<path d="M19 12H5"/><path d="m12 19-7-7 7-7"/>'),
  speaker: svg('<path d="M11 5 6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M19 5a10 10 0 0 1 0 14"/>'),
  stop: svg('<rect x="6" y="6" width="12" height="12" rx="2"/>'),
  alert: svg('<circle cx="12" cy="12" r="10"/><path d="M12 8v4"/><path d="M12 16h.01"/>'),
  shield: svg('<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>'),
  clock: svg('<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>'),
  user: svg('<path d="M18 20a6 6 0 0 0-12 0"/><circle cx="12" cy="10" r="4"/><path d="m3 3 18 18"/>'),
  heart: svg('<path d="M19 14c1.5-1.5 3-3.2 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.8 0-3 .5-4.5 2-1.5-1.5-2.7-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4 3 5.5l7 7z"/>'),
  info: svg('<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>'),
  wifi: svg('<path d="M12 20h.01"/><path d="M8.5 16.4a5 5 0 0 1 7 0"/><path d="M5 12.9a10 10 0 0 1 5.2-2.8"/><path d="M19 12.9a10 10 0 0 0-2-1.5"/><path d="m2 2 20 20"/>'),
};

const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const $app = document.getElementById('app');
const isTest = new URLSearchParams(location.search).get('test') === '1';

/* ---------- state ---------- */
let state = freshState();
let pendingRow = null;   // row being sent (kept for retry with the same response_id)
let speaking = false;

function freshState() {
  return { answers: {}, page: 0, screenQ: null, startedAt: Date.now(), responseId: newResponseId(), isTest };
}
// drafts saved by the older one-question-per-screen version stored "current" instead of "page"
function fromDraft(d) {
  const st = { ...freshState(), ...d };
  if (typeof st.page !== 'number') st.page = Math.max(0, pageIndexOf(d.current || 'q1'));
  delete st.current;
  return st;
}
const persist = () => store.saveDraft(state);

/* ---------- navigation ----------
   History holds only one "guard" entry above the page. The Android/browser Back button
   pops it and we treat that exactly like the in-app ย้อนกลับ button, then re-arm the guard.
   So history never replays old screens or skips validation. */
let currentScreen = 'intro';
let guarded = false;
function armGuard() { if (!guarded) { history.pushState({ guard: 1 }, ''); guarded = true; } }

function go(screen) {
  stopSpeaking(); speaking = false;
  if (screen !== 'intro') armGuard();
  render(screen);
}
function goBack() {
  if (currentScreen === 'page') {
    if (state.page > 0) { state.page--; persist(); go('page'); } else go('intro');
  } else if (currentScreen === 'confirm') {
    go('page');
  }
  // sending / failed / thanks / intro: stay where we are
}
window.addEventListener('popstate', () => {
  guarded = false;
  if (currentScreen === 'intro') return;          // let the next Back leave the page
  goBack();
  armGuard();
});

/* ---------- screens ---------- */
function render(screen) {
  currentScreen = screen;
  const fn = { intro: renderIntro, page: renderPage, confirm: renderConfirm, sending: renderSending, failed: renderFailed, thanks: renderThanks }[screen];
  fn();
  const h = $app.querySelector('[data-focus]');
  if (h) { h.setAttribute('tabindex', '-1'); h.focus({ preventScroll: true }); }
  window.scrollTo(0, 0);
}

function renderIntro() {
  const draft = store.loadDraft();
  const hasDraft = draft && draft.answers && Object.keys(draft.answers).length > 0;
  $app.innerHTML = `
    <div class="hero content anim">
      <h1 data-focus>${esc(INTRO_TITLE)}</h1>
      <p class="subtitle">${esc(INTRO_SUBTITLE)}</p>
      <ul class="facts">
        <li>${I.user}<span>ไม่ต้องบอกชื่อ ที่ทำงาน หรือเบอร์โทร</span></li>
        <li>${I.clock}<span>ใช้เวลาประมาณ 6 นาที</span></li>
        <li>${I.heart}<span>ไม่มีถูกผิด ตอบตามที่รู้สึก</span></li>
      </ul>
    </div>
    <div class="actions"><div class="actions-inner stack" style="display:grid">
      ${hasDraft
        ? `<button class="btn btn-primary btn-block" data-act="resume">ทำต่อ ${I.next}</button>
           <button class="btn btn-secondary btn-block" data-act="new">เริ่มใหม่ (คนใหม่)</button>`
        : `<button class="btn btn-primary btn-block" data-act="start">เริ่มตอบ ${I.next}</button>`}
    </div></div>`;
  if (hasDraft) $app.querySelector('.content').classList.add('two-actions');
  on('[data-act="start"]', () => { state = freshState(); persist(); go('page'); });
  on('[data-act="resume"]', () => { state = fromDraft(draft); go('page'); });
  on('[data-act="new"]', () => { store.clearDraft(); state = freshState(); persist(); go('page'); });
}

const PAGE_TITLES = ['ข้อมูลเบื้องต้น'];
const pageTitle = i => PAGE_TITLES[i] || sectionOf(getQuestion(PAGES[i][0])).title;

/* One scrolling page per section (screening q1-q4 share the first page). */
function renderPage() {
  const i = state.page;
  const total = PAGES.length;
  const isLast = i === total - 1;
  const sec = sectionOf(getQuestion(PAGES[i][0]));
  $app.innerHTML = `
    <header class="topbar">
      <div class="topbar-row"><strong>หน้า ${i + 1}</strong><span>จาก ${total}</span></div>
      <div class="progress" role="progressbar" aria-label="ความคืบหน้า" aria-valuemin="1" aria-valuemax="${total}" aria-valuenow="${i + 1}"><span style="width:${Math.round((i + 1) / total * 100)}%"></span></div>
    </header>
    <div class="content anim">
      <h1 class="page-title" data-focus>${esc(pageTitle(i))}</h1>
      ${i > 0 && sec.description ? `<p class="section-note">${esc(sec.description)}</p>` : ''}
      <div id="page-body">${PAGES[i].map(id => cardHtml(getQuestion(id))).join('')}</div>
    </div>
    <nav class="actions" aria-label="เปลี่ยนหน้า"><div class="actions-inner">
      <button type="button" class="btn btn-secondary" data-act="prev">${I.back}<span>ย้อนกลับ</span></button>
      <button type="button" class="btn btn-primary" data-act="next">${isLast ? `<span>ส่งคำตอบ</span>${I.check}` : `<span>ถัดไป</span>${I.next}`}</button>
    </div></nav>`;
  bindPage();
}

function cardHtml(q) {
  const { title, hint } = splitHint(q.text);
  const hidden = q.showIf && !q.showIf(state.answers);
  return `<section class="qcard" id="card-${q.id}" data-q="${q.id}" ${hidden ? 'hidden' : ''}>
    <h2 class="q-title" id="title-${q.id}"><span class="qno">${q.num}</span>${esc(title)}</h2>
    ${hint ? `<p class="q-hint">${esc(hint)}</p>` : ''}
    ${canSpeakThai() ? `<button type="button" class="listen" data-listen="${q.id}" aria-pressed="false">${I.speaker}<span>ฟังคำถาม</span></button>` : ''}
    <div class="q-body">${bodyHtml(q)}</div>
    <div class="error" id="err-${q.id}" role="alert"></div>
  </section>`;
}

function bodyHtml(q) {
  const v = state.answers[q.id];
  if (q.type === 'single' || q.type === 'multi') {
    const multi = q.type === 'multi';
    const sel = multi ? (v || []) : [v];
    const full = multi && q.max && sel.filter(c => !q.options.find(o => o.code === c)?.exclusive).length >= q.max;
    const counter = multi && q.max
      ? `<p class="counter ${full ? 'full' : ''}" aria-live="polite">${full ? `ครบ ${q.max} ข้อแล้ว · จะเปลี่ยน กดข้อเดิมออกก่อน` : `เลือกได้ ${q.max} ข้อ · เลือกแล้ว ${sel.length}`}</p>` : '';
    const opts = q.options.map(o => {
      const checked = sel.includes(o.code);
      const dim = full && !checked && !o.exclusive;
      return `<label class="option ${multi ? 'check' : 'radio'} ${dim ? 'dim' : ''}">
        <input type="${multi ? 'checkbox' : 'radio'}" name="${q.id}" value="${esc(o.code)}" ${checked ? 'checked' : ''}>
        <span class="mark">${multi ? I.check : I.dot}</span>
        <span class="label">${esc(o.label)}${o.detail ? `<span class="detail">${esc(o.detail)}</span>` : ''}</span>
      </label>`;
    }).join('');
    const other = q.options.some(o => o.other) && sel.includes('other')
      ? `<label class="field-label" for="other-${q.id}">พิมพ์เพิ่มได้ (ไม่ต้องพิมพ์ก็ได้)</label>
         <input class="text-input" id="other-${q.id}" data-other="${q.id}" maxlength="300" value="${esc(state.answers[`${q.id}_other`] || '')}" autocomplete="off">
         <p class="helper">${I.info}<span>${esc(q.helper)}</span></p>` : '';
    return `${counter}<fieldset aria-labelledby="title-${q.id}"><div class="options">${opts}</div></fieldset>${other}`;
  }
  if (q.type === 'grid') {
    const g = v || {};
    return q.rows.map((r, n) => `
      <fieldset class="grid-row ${g[r.code] ? 'done' : ''}">
        <legend>${n + 1}. ${esc(r.label)}</legend>
        <div class="seg">${q.cols.map(c => `
          <label><input type="radio" name="${q.id}_${r.code}" data-row="${r.code}" value="${c.code}" ${g[r.code] === c.code ? 'checked' : ''}>${esc(c.label)}</label>`).join('')}
        </div>
      </fieldset>`).join('');
  }
  return `<label class="sr-only" for="text-${q.id}">${esc(q.text)}</label>
    <textarea id="text-${q.id}" data-text="${q.id}" maxlength="1000" autocomplete="off">${esc(v || '')}</textarea>
    <p class="helper">${I.info}<span>${esc(q.helper)}</span></p>`;
}

const setErr = (id, msg) => {
  const el = $app.querySelector(`#err-${id}`);
  if (el) el.innerHTML = msg ? `${I.alert}<span>${esc(msg)}</span>` : '';
  $app.querySelector(`#card-${id}`)?.classList.toggle('has-error', !!msg);
};

/** Show/hide questions whose visibility depends on other answers (q29 after q28). */
function syncVisibility() {
  for (const card of $app.querySelectorAll('.qcard')) {
    const q = getQuestion(card.dataset.q);
    if (q.showIf) card.hidden = !q.showIf(state.answers);
  }
}

function bindPage() {
  const page = $app.querySelector('#page-body');

  page.addEventListener('change', e => {
    const t = e.target;
    const card = t.closest('[data-q]');
    if (!card) return;
    const q = getQuestion(card.dataset.q);
    if (q.type === 'single') {
      state.answers[q.id] = t.value;
    } else if (q.type === 'multi' && t.type === 'checkbox') {
      const res = toggleMulti(q, state.answers[q.id] || [], t.value);
      state.answers[q.id] = res.value;
      const body = card.querySelector('.q-body');
      body.innerHTML = bodyHtml(q);
      body.querySelector(`input[value="${CSS.escape(t.value)}"]`)?.focus({ preventScroll: true });
      setErr(q.id, res.blocked ? `เลือกได้ไม่เกิน ${q.max} ข้อ` : '');
      syncVisibility();
      persist();
      return;
    } else if (q.type === 'grid') {
      state.answers[q.id] = { ...(state.answers[q.id] || {}), [t.dataset.row]: t.value };
      t.closest('.grid-row').classList.add('done');
    } else {
      return;
    }
    setErr(q.id, '');
    syncVisibility();
    persist();
  });
  page.addEventListener('input', e => {
    const t = e.target;
    if (t.dataset.other) state.answers[`${t.dataset.other}_other`] = t.value;
    if (t.dataset.text) state.answers[t.dataset.text] = t.value;
  });
  page.addEventListener('focusout', e => { if (e.target.dataset.other || e.target.dataset.text) persist(); });

  page.addEventListener('click', e => {
    const btn = e.target.closest('[data-listen]');
    if (!btn) return;
    const wasThis = btn.getAttribute('aria-pressed') === 'true';
    stopSpeaking(); speaking = false;
    $app.querySelectorAll('[data-listen]').forEach(b => b.setAttribute('aria-pressed', 'false'));
    if (wasThis) return;
    const q = getQuestion(btn.dataset.listen);
    const parts = [splitHint(q.text).title];
    if (q.options) parts.push(...q.options.map(o => o.label + (o.detail ? ' ' + o.detail : '')));
    if (q.rows) parts.push(...q.rows.map(r => r.label), 'ตอบได้ว่า ' + q.cols.map(c => c.label).join(' หรือ '));
    speaking = true; btn.setAttribute('aria-pressed', 'true');
    speak(parts.join(' ... '), () => { speaking = false; btn.setAttribute('aria-pressed', 'false'); });
  });

  on('[data-act="prev"]', goBack);

  on('[data-act="next"]', () => {
    persist();
    const i = state.page;
    for (const id of PAGES[i]) setErr(id, '');
    const problems = pageProblems(i, state.answers);
    if (problems.length) {
      for (const p of problems) setErr(p.id, p.message);
      showQuestion(problems[0].id);
      return;
    }
    const out = pageScreenOut(i, state.answers);
    if (out) { state.screenQ = out.id; persist(); go('confirm'); return; }
    if (i < PAGES.length - 1) { state.page = i + 1; persist(); go('page'); }
    else submit('complete');
  });
}

/** Scroll a question into view (below the sticky header) and put focus on its first input. */
function showQuestion(id) {
  const card = $app.querySelector(`#card-${id}`);
  if (!card) return;
  const top = card.getBoundingClientRect().top + window.scrollY - 90;
  window.scrollTo({ top, behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' });
  card.querySelector('.grid-row:not(.done) input, input, textarea')?.focus({ preventScroll: true });
}

function renderConfirm() {
  const q = getQuestion(state.screenQ);
  const label = q.options.find(o => o.code === state.answers[q.id])?.label || '';
  $app.innerHTML = `
    <div class="hero content anim">
      <div class="hero-icon">${I.info}</div>
      <h1 data-focus>คุณเลือก "${esc(label)}" ใช่ไหม</h1>
      <p>ถ้าใช่ แบบสำรวจจะจบเลย</p>
    </div>
    <div class="actions"><div class="actions-inner">
      <button class="btn btn-secondary" data-act="edit">${I.back}<span>แก้คำตอบ</span></button>
      <button class="btn btn-primary" data-act="yes">ใช่</button>
    </div></div>`;
  on('[data-act="edit"]', () => { state.page = pageIndexOf(q.id); go('page'); requestAnimationFrame(() => showQuestion(q.id)); });
  on('[data-act="yes"]', () => submit('screened_out', q.num));
}

function renderSending() {
  $app.innerHTML = `<div class="hero content center end"><div class="spinner" role="status" aria-label="กำลังส่ง"></div><h1 data-focus>กำลังส่ง…</h1><p>อย่าเพิ่งปิดหน้านี้</p></div>`;
}

function renderFailed() {
  $app.innerHTML = `
    <div class="hero content center end anim">
      <div class="hero-icon" style="background:var(--error-soft);color:var(--error)">${I.wifi}</div>
      <h1 data-focus>ส่งไม่สำเร็จ</h1>
      <p>เช็กอินเทอร์เน็ต แล้วกดส่งอีกครั้ง<br>คำตอบยังอยู่ ไม่หาย</p>
    </div>
    <div class="actions"><div class="actions-inner">
      <button class="btn btn-primary" data-act="retry">ส่งอีกครั้ง</button>
    </div></div>`;
  on('[data-act="retry"]', () => send());
}

function renderThanks() {
  $app.innerHTML = `
    <div class="hero content center end anim">
      <div class="hero-icon">${I.check}</div>
      <h1 data-focus>${esc(THANKS_TEXT)}</h1>
      <p style="color:var(--text-muted)">ปิดหน้านี้ได้เลย</p>
    </div>
    <div class="actions"><div class="actions-inner">
      <button class="btn btn-ghost btn-block" data-act="again">ให้คนอื่นตอบต่อในเครื่องนี้</button>
    </div></div>`;
  on('[data-act="again"]', () => { state = freshState(); go('intro'); });
}

/* ---------- submit ---------- */
function submit(status, screenedAtQ) {
  let answers = state.answers;
  if (status === 'complete') {
    // safety net: never send "complete" with a screen-out or missing answer
    const problem = firstProblem(answers);
    if (problem) {
      state.page = pageIndexOf(problem.id);
      if (problem.type === 'screened') { state.screenQ = problem.id; persist(); go('confirm'); return; }
      persist(); go('page');
      setErr(problem.id, 'ข้อนี้ยังไม่ได้ตอบ กรุณาตอบก่อนส่ง');
      requestAnimationFrame(() => showQuestion(problem.id));
      return;
    }
  }
  if (status === 'screened_out') {
    answers = Object.fromEntries(Object.entries(answers).filter(([k]) => {
      const n = Number(k.replace(/^q(\d+).*/, '$1')); return n && n <= screenedAtQ;
    }));
  }
  pendingRow = toRow({ answers, status, screenedAtQ, startedAt: state.startedAt, now: Date.now(), isTest: state.isTest, responseId: state.responseId });
  store.pushPending(pendingRow);
  send();
}

let inFlight = false;
async function send() {
  if (inFlight || !pendingRow) return;
  inFlight = true;
  render('sending');
  const res = await submitRow(pendingRow, { hp: document.getElementById('hp')?.value || '' });
  inFlight = false;
  if (res.ok) {
    store.removePending(pendingRow.response_id);
    store.clearDraft();
    pendingRow = null;
    state = freshState();   // forget this person's answers in memory too (not persisted)
    render('thanks');
  } else {
    render('failed');
  }
}

/* rows stuck from an earlier visit (e.g. phone went offline) are retried quietly */
async function flushPending() {
  if (!API_URL) return;
  for (const row of store.loadPending()) {
    if (pendingRow && row.response_id === pendingRow.response_id) continue;
    const res = await submitRow(row);
    if (res.permanent) { store.removePending(row.response_id); continue; } // server will never accept it
    if (res.ok) {
      store.removePending(row.response_id);
      // that person's draft is already submitted: drop it so nobody "resumes" it
      if (store.loadDraft()?.responseId === row.response_id) {
        store.clearDraft();
        if (currentScreen === 'intro') render('intro');
      }
    }
  }
}

function on(sel, fn) {
  const el = $app.querySelector(sel);
  if (el) el.addEventListener('click', () => fn(el));
}

/* ---------- boot ---------- */
if (!API_URL || isTest) {
  const b = document.getElementById('demo-banner');
  b.hidden = false;
  b.textContent = !API_URL ? 'โหมดทดลอง: ไม่ได้เชื่อมเซิร์ฟเวอร์ คำตอบจะเก็บไว้ในเครื่องนี้เท่านั้น' : 'โหมดทดสอบ: คำตอบนี้จะถูกทำเครื่องหมายว่าเป็นข้อมูลทดสอบ';
}
render('intro');
onVoicesReady(() => { if (currentScreen === 'page' && !$app.querySelector('.listen')) render('page'); });
flushPending();
