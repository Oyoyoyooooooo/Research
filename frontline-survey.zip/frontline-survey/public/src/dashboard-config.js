// One card per row of the PDF's "ตารางเทียบข้อที่ใช้วิเคราะห์".
// kinds: single | multi | grid | crosstab {a,b} | crossMulti {m,g} | list {key}
export const CHARTS = [
  { title: 'กลุ่มย่อย', ref: 'ข้อ 1, 2, 5, 6, 9', items: [
    { kind: 'single', q: 1 }, { kind: 'single', q: 2 }, { kind: 'single', q: 5 }, { kind: 'single', q: 6 }, { kind: 'single', q: 9 }] },
  { title: 'ภาระประจำเดือน', ref: 'ข้อ 7, 10, 12, 13', items: [
    { kind: 'single', q: 7 }, { kind: 'single', q: 10 }, { kind: 'single', q: 12 }, { kind: 'single', q: 13 }] },
  { title: 'ภาระก้อนใหญ่', ref: 'ข้อ 14', items: [{ kind: 'single', q: 14 }] },
  { title: 'ความเสี่ยงที่เคยเจอจริง เทียบกับที่คิดว่าจะเกิด', ref: 'ข้อ 19 เทียบ 20 (ประเมินความเสี่ยงต่ำเกินจริงไหม)', items: [
    { kind: 'grid', q: 19 }, { kind: 'grid', q: 20 }] },
  { title: 'เหตุร้ายที่หนักที่สุด และความกังวล', ref: 'ข้อ 21 เทียบ 18', items: [{ kind: 'single', q: 21 }, { kind: 'multi', q: 18 }] },
  { title: 'ช่องว่างตอนหยุดงานแล้วไม่ได้ค่าแรง', ref: 'ข้อ 6 เทียบ 23', items: [{ kind: 'crosstab', a: 6, b: 23, title: 'ค่าแรงแบบไหน × ได้ค่าแรงตอนป่วยไหม' }] },
  { title: 'เงินที่ใช้รับมือจริง', ref: 'ข้อ 22 เทียบ 25', items: [{ kind: 'multi', q: 22 }, { kind: 'single', q: 25 }] },
  { title: 'ความรู้สึก vs ความจริง', ref: 'ข้อ 16 เทียบ 25', items: [{ kind: 'crosstab', a: 16, b: 25, title: 'คิดว่าอยู่ได้นานแค่ไหน × เงินเก็บพอจริงแค่ไหน' }] },
  { title: 'ความคุ้มครองที่มีจริง', ref: 'ข้อ 15, 24', items: [{ kind: 'multi', q: 15 }, { kind: 'multi', q: 24 }] },
  { title: 'ใครมาก่อน', ref: 'ข้อ 17', items: [{ kind: 'single', q: 17 }] },
  { title: 'สาเหตุที่ไม่ซื้อ', ref: 'ข้อ 27', items: [{ kind: 'multi', q: 27 }, { kind: 'list', key: 'q27_other_text', title: 'ข้อความ "อื่นๆ" ที่พิมพ์เอง' }] },
  { title: 'ความพร้อมใช้ช่องทางดิจิทัล', ref: 'ข้อ 26 เทียบ 32', items: [{ kind: 'single', q: 26 }, { kind: 'multi', q: 32 }] },
  { title: 'ไอเดียที่ชนะ', ref: 'ข้อ 28-29 แยกตามอาชีพ และเหตุร้ายในข้อ 21', items: [
    { kind: 'multi', q: 28 }, { kind: 'single', q: 29 }, { kind: 'crossMulti', m: 28, g: 1, title: 'ไอเดียที่เลือก แยกตามอาชีพ' }, { kind: 'crossMulti', m: 28, g: 21, title: 'ไอเดียที่เลือก แยกตามเหตุร้ายที่กลัวที่สุด' }] },
  { title: 'ความสามารถจ่ายและวิธีจ่าย', ref: 'ข้อ 30-31', items: [{ kind: 'single', q: 30 }, { kind: 'single', q: 31 }] },
  { title: 'เสียงจากผู้ตอบ', ref: 'ข้อ 33', items: [{ kind: 'list', key: 'q33', title: 'ข้อความที่ผู้ตอบเขียนเพิ่ม' }] },
];
