// Builds sheet data (arrays of arrays) for the .xlsx download. The browser turns it into
// a workbook with SheetJS (window.XLSX); this module stays pure so it can be tested in Node.
import { buildColumns, codebook } from './record.js';
import { funnel } from './stats.js';

const NUMERIC_KINDS = new Set(['flag']);
const NUMERIC_SYSTEM = new Set(['screened_at_q', 'duration_sec', 'is_test']);

function cell(col, v) {
  if (v === '' || v == null) return '';
  if (NUMERIC_KINDS.has(col.kind) || NUMERIC_SYSTEM.has(col.key)) {
    const n = Number(v);
    return Number.isFinite(n) ? n : String(v);
  }
  return String(v);
}

export function workbookData(rows) {
  const cols = buildColumns();
  const responses = [cols.map(c => c.key), ...rows.map(r => cols.map(c => cell(c, r[c.key])))];
  const cb = [['คอลัมน์', 'คำถาม', 'ตัวเลือก/ความหมาย'], ...codebook().map(r => [r.key, r.question, r.option])];
  const f = funnel(rows, { includeTest: false });
  const summary = [
    ['รายการ', 'จำนวน'],
    ['ตอบครบ (ไม่นับข้อมูลทดสอบ)', f.complete],
    ...Object.entries(f.byOccupation).map(([k, v]) => [`ตอบครบ: ${k}`, v]),
    ...Object.entries(f.screened).map(([k, v]) => [`ถูกคัดออกที่ข้อ ${k}`, v]),
    ['ข้อมูลทดสอบ (is_test = 1)', rows.filter(r => String(r.is_test) === '1').length],
  ];
  return { responses, codebook: cb, summary };
}

/** Browser only: download as .xlsx using the global SheetJS build. */
export function downloadXlsx(rows, XLSX = globalThis.XLSX) {
  const data = workbookData(rows);
  const wb = XLSX.utils.book_new();
  const add = (aoa, name, widths) => {
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    if (widths) ws['!cols'] = widths.map(w => ({ wch: w }));
    XLSX.utils.book_append_sheet(wb, ws, name);
  };
  add(data.responses, 'responses');
  add(data.codebook, 'codebook', [20, 70, 50]);
  add(data.summary, 'summary', [40, 10]);
  const d = new Date();
  const stamp = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  XLSX.writeFile(wb, `survey-responses-${stamp}.xlsx`);
}
