// Read questions aloud with the phone's Thai voice, when it has one.
let thaiVoice = null;

function pickVoice() {
  const synth = globalThis.speechSynthesis;
  if (!synth) return null;
  thaiVoice = synth.getVoices().find(v => /^th(-|_|$)/i.test(v.lang)) || null;
  return thaiVoice;
}

export function canSpeakThai() {
  return !!(thaiVoice || pickVoice());
}

export function onVoicesReady(cb) {
  const synth = globalThis.speechSynthesis;
  if (!synth) return;
  if (pickVoice()) { cb(); return; }
  synth.addEventListener?.('voiceschanged', () => { if (pickVoice()) cb(); }, { once: true });
}

export function speak(text, onEnd) {
  const synth = globalThis.speechSynthesis;
  if (!synth || !canSpeakThai()) return;
  synth.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.voice = thaiVoice;
  u.lang = thaiVoice.lang;
  u.rate = 0.9;
  if (onEnd) { u.onend = onEnd; u.onerror = onEnd; }
  synth.speak(u);
}

export function stopSpeaking() {
  globalThis.speechSynthesis?.cancel();
}
