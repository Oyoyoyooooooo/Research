import { API_URL, SURVEY_URL } from '../config.js';
import { getQuestion, splitHint } from './questions.js';
import { qKey } from './record.js';
import { fetchRows } from './api.js';
import { filterRows, countSingle, countMulti, crosstab, crossMulti, gridSummary, funnel } from './stats.js';
import { sampleRows } from './sample.js';
import { downloadXlsx } from './export-xlsx.js';
import { CHARTS } from './dashboard-config.js';

const $root = document.getElementById('dash');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const fmtPct = p => `${p.toFixed(p >= 10 || p === 0 ? 0 : 1)}%`;
const SERIES = ['var(--series-1)', 'var(--series-2)', 'var(--series-3)', 'var(--series-4)', 'var(--series-5)'];
const GOAL = 30;
const svg = d => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
const ICON = {
  download: svg('<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/>'),
  refresh: svg('<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>'),
  qr: svg('<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><path d="M14 14h3v3h-3zM20 14v.01M14 20h.01M17 17h4v4"/>'),
  logout: svg('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>'),
};

const view = { rows: [], source: null, occupation: 'all', includeTest: false, error: '' };

const session = {
  get: () => { try { return sessionStorage.getItem('team_key'); } catch { return null; } },
  set: v => { try { sessionStorage.setItem('team_key', v); } catch { /* ignore */ } },
  clear: () => { try { sessionStorage.removeItem('team_key'); } catch { /* ignore */ } },
};

/* ---------------- gate ---------------- */
function renderGate(message = '') {
  $root.innerHTML = `
    <div class="wrap"><div class="gate">
      <h1>สรุปผลแบบสำรวจ (สำหรับทีม)</h1>
      <p>ห้ามแชร์ข้อมูลหน้านี้ให้นายจ้างหรือหัวหน้างาน</p>
      ${message ? `<p class="banner err" role="alert">${esc(message)}</p>` : ''}
      ${API_URL ? `
        <form id="gate-form">
          <label for="key">รหัสทีม</label>
          <input id="key" type="password" autocomplete="current-password" required>
          <button class="btn btn-primary" type="submit">เข้าดู</button>
        </form>
        <p class="or">หรือ</p>` : `<p class="banner sample">เปิดไฟล์โดยไม่ผ่านเซิร์ฟเวอร์ (API_URL ว่าง) ตอนนี้ดูได้เฉพาะข้อมูลตัวอย่าง</p>`}
      <button class="btn btn-secondary btn-block" id="use-sample" type="button">ดูด้วยข้อมูลตัวอย่าง</button>
    </div></div>`;
  document.getElementById('gate-form')?.addEventListener('submit', e => {
    e.preventDefault();
    const key = document.getElementById('key').value.trim();
    if (key) loadLive(key);
  });
  document.getElementById('use-sample').addEventListener('click', loadSample);
}

async function loadLive(key) {
  $root.innerHTML = `<div class="wrap"><div class="gate center"><div class="spinner" role="status" aria-label="กำลังโหลด"></div><p>กำลังโหลดข้อมูล…</p></div></div>`;
  try {
    const rows = await fetchRows(key);
    session.set(key);
    Object.assign(view, { rows, source: 'live', error: '' });
    renderDash();
  } catch (e) {
    session.clear();
    renderGate({
      bad_key: 'รหัสทีมไม่ถูกต้อง',
      not_configured: 'ยังไม่ได้ตั้งรหัสทีม: ใส่ TEAM_KEY ใน Vercel → Settings → Environment Variables แล้วกด Redeploy',
      no_database: 'ยังไม่ได้เชื่อมฐานข้อมูล: สร้าง Neon ใน Vercel → Storage แล้วกด Connect และ Redeploy',
    }[e.message] || 'โหลดข้อมูลไม่สำเร็จ ตรวจสอบอินเทอร์เน็ตแล้วลองใหม่');
  }
}

function loadSample() {
  let local = [];
  if (!API_URL) { try { local = JSON.parse(localStorage.getItem('demo_submissions') || '[]'); } catch { /* ignore */ } }
  Object.assign(view, { rows: [...sampleRows(120, 1), ...local], source: 'sample', error: '' });
  renderDash();
}

/* ---------------- charts ---------------- */
function base(n, multi) {
  return `<p class="base">${n} คนตอบ${multi ? ' · เลือกได้หลายข้อ' : ''}</p>`;
}
const qTitle = q => `<h3><span class="qnum">ข้อ ${q.num}</span> ${esc(splitHint(q.text).title)}</h3>`;

function barsHtml(items) {
  const max = Math.max(1, ...items.map(i => i.pct));
  return `<div class="bars">${items.map(i => `
    <div class="bar-row" title="${esc(i.label)}: ${i.n} คน (${fmtPct(i.pct)})">
      <div class="b-label">${esc(i.label)}</div>
      <div class="b-track"><div class="b-fill" style="width:${(i.pct / max) * 100}%"></div></div>
      <div class="b-val">${i.n} <small>(${fmtPct(i.pct)})</small></div>
    </div>`).join('')}</div>`;
}

function answeredCount(rows, q) {
  const key = qKey(q.num);
  return rows.filter(r => r[key] !== '' && r[key] != null).length;
}

function legendHtml(labels) {
  return `<div class="legend">${labels.map((l, i) => `<span><i style="background:${SERIES[i]}"></i>${esc(l)}</span>`).join('')}</div>`;
}

function stackRow(label, counts, labels, sub = '') {
  const total = counts.reduce((a, b) => a + b, 0);
  const segs = counts.map((c, i) => {
    if (!c) return '';
    const p = (c / total) * 100;
    return `<span style="flex:${c};background:${SERIES[i]}" title="${esc(labels[i])}: ${c} คน (${fmtPct(p)})">${p >= 12 ? fmtPct(p) : ''}</span>`;
  }).join('');
  return `<div class="stack-row"><div class="s-label">${esc(label)} <small>${sub || `(${total} คน)`}</small></div>
    <div class="stack" role="img" aria-label="${esc(label)}: ${labels.map((l, i) => `${l} ${counts[i]}`).join(', ')}">${total ? segs : '<span style="flex:1;background:var(--track)"></span>'}</div></div>`;
}

function tableHtml(head, body) {
  return `<div class="tbl-wrap"><table class="t"><thead><tr>${head.map(h => `<th scope="col">${esc(h)}</th>`).join('')}</tr></thead>
    <tbody>${body.map(r => `<tr>${r.map((c, i) => i === 0 ? `<th scope="row">${esc(c)}</th>` : `<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}

function chartHtml(item, rows) {
  if (item.kind === 'single' || item.kind === 'multi') {
    const q = getQuestion(`q${item.q}`);
    const n = answeredCount(rows, q);
    const data = item.kind === 'single' ? countSingle(rows, item.q) : countMulti(rows, item.q);
    return `<div class="chart">${qTitle(q)}${base(n, item.kind === 'multi')}
      ${n ? barsHtml(data) : '<p class="empty">ยังไม่มีคำตอบ</p>'}</div>`;
  }
  if (item.kind === 'grid') {
    const q = getQuestion(`q${item.q}`);
    const g = gridSummary(rows, item.q);
    const cols = q.cols.map(c => c.label);
    return `<div class="chart">${qTitle(q)}${legendHtml(cols)}
      ${g.map(r => stackRow(r.row, cols.map(c => r.counts[c]), cols)).join('')}
      <details class="tv"><summary>ดูเป็นตาราง</summary>${tableHtml(['เหตุการณ์', ...cols], g.map(r => [r.row, ...cols.map(c => r.counts[c])]))}</details></div>`;
  }
  if (item.kind === 'crosstab') {
    const qa = getQuestion(`q${item.a}`), qb = getQuestion(`q${item.b}`);
    const t = crosstab(rows, item.a, item.b);
    return `<div class="chart"><h3><span class="qnum">ข้อ ${qa.num} × ${qb.num}</span> ${esc(item.title)}</h3>
      <p class="base">แถว = ข้อ ${qa.num} · สี = ข้อ ${qb.num}</p>
      ${legendHtml(t.b)}${t.a.map((a, i) => stackRow(a, t.cells[i], t.b)).join('')}
      <details class="tv"><summary>ดูเป็นตาราง</summary>${tableHtml([`ข้อ ${qa.num} \\ ข้อ ${qb.num}`, ...t.b], t.a.map((a, i) => [a, ...t.cells[i]]))}</details></div>`;
  }
  if (item.kind === 'crossMulti') {
    const qm = getQuestion(`q${item.m}`), qg = getQuestion(`q${item.g}`);
    const t = crossMulti(rows, item.m, item.g);
    const short = t.options.map(o => o.split(' ').slice(0, 2).join(' '));
    const body = t.groups.map((g, i) => [g, `${t.n[i]}`, ...t.pct[i].map(p =>
      `<span style="display:inline-block;min-width:44px;padding:2px 6px;border-radius:4px;background:rgba(15,118,110,${t.n[i] ? (p / 100) * 0.55 : 0})">${t.n[i] ? fmtPct(p) : '–'}</span>`)]);
    return `<div class="chart"><h3><span class="qnum">ข้อ ${qm.num} × ${qg.num}</span> ${esc(item.title)}</h3>
      <p class="base">% ของแต่ละกลุ่มที่เลือก · สีเข้ม = เลือกมาก</p>
      ${tableHtml(['กลุ่ม', 'คน', ...short], body)}</div>`;
  }
  if (item.kind === 'list') {
    const texts = rows.map(r => r[item.key]).filter(v => v && String(v).trim());
    return `<div class="chart"><h3>${esc(item.title)}</h3><p class="base">${texts.length} ข้อความ</p>
      ${texts.length ? `<ul class="quotes">${texts.map(t => `<li>${esc(String(t).replace(/^'/, ''))}</li>`).join('')}</ul>` : '<p class="empty">ยังไม่มีข้อความ</p>'}</div>`;
  }
  return '';
}

/* ---------------- dashboard ---------------- */
function renderDash() {
  const all = view.rows;
  const rows = filterRows(all, { occupation: view.occupation, includeTest: view.includeTest, status: 'complete' });
  const f = funnel(all, { includeTest: view.includeTest });
  const screenedTotal = Object.values(f.screened).reduce((a, b) => a + b, 0);
  const occs = Object.keys(f.byOccupation);

  $root.innerHTML = `
    <header class="d-head"><div class="wrap">
      <div><h1>สรุปผลแบบสำรวจ</h1><div class="src">${view.source === 'sample' ? 'ข้อมูลตัวอย่าง' : 'ข้อมูลจริงจากฐานข้อมูล'} · ${all.length} แถว</div></div>
      <div class="toolbar">
        ${view.source === 'live' ? `<button class="btn-sm" id="refresh">${ICON.refresh}รีเฟรช</button>` : ''}
        <button class="btn-sm" id="qr">${ICON.qr}QR code</button>
        <button class="btn-sm primary" id="xlsx">${ICON.download}ดาวน์โหลด Excel</button>
        <button class="btn-sm" id="logout">${ICON.logout}ออก</button>
      </div>
    </div></header>
    <main class="wrap">
      ${view.source === 'sample' ? '<p class="banner sample">ข้อมูลตัวอย่าง (ไม่ใช่ของจริง)</p>' : ''}
      <div class="filters">
        <div class="chips" role="group" aria-label="กรองตามอาชีพ">
          ${['all', ...occs].map(o => `<button class="chip" data-occ="${esc(o)}" aria-pressed="${view.occupation === o}">${o === 'all' ? 'ทุกอาชีพ' : esc(o)}</button>`).join('')}
        </div>
        <label class="check-inline"><input type="checkbox" id="inc-test" ${view.includeTest ? 'checked' : ''}> รวมข้อมูลทดสอบ</label>
      </div>
      <section class="kpis" aria-label="ภาพรวม">
        <div class="kpi"><div class="k-label">ตอบครบ${view.occupation === 'all' ? '' : ` (${esc(view.occupation)})`}</div><div class="k-value">${rows.length}</div><div class="k-sub">เป้า 100-150</div></div>
        ${occs.map(o => {
          const n = f.byOccupation[o];
          return `<div class="kpi ${n >= GOAL ? 'goal-met' : ''}"><div class="k-label">${esc(o)}</div><div class="k-value">${n}</div>
            <div class="meter" aria-hidden="true"><span style="width:${Math.min(100, (n / GOAL) * 100)}%"></span></div>
            <div class="k-sub">${n >= GOAL ? 'ครบ 30 แล้ว' : `ขาดอีก ${GOAL - n} คน`}</div></div>`;
        }).join('')}
        <div class="kpi"><div class="k-label">ถูกคัดออก</div><div class="k-value">${screenedTotal}</div>
          <div class="k-sub">ข้อ 1: ${f.screened[1]} · ข้อ 2: ${f.screened[2]} · ข้อ 3: ${f.screened[3]} · ข้อ 4: ${f.screened[4]}</div></div>
      </section>
      <div class="cards">
        ${CHARTS.map(c => `<section class="card ${c.items.some(i => i.kind === 'crossMulti') ? 'wide' : ''}">
          <h2>${esc(c.title)}</h2>
          ${c.items.map(i => chartHtml(i, rows)).join('')}
        </section>`).join('')}
      </div>
    </main>
    <dialog class="qr" id="qr-dialog"><h2 style="margin:0 0 12px;font-size:1.1rem">QR code แบบสำรวจ</h2>
      <canvas id="qr-canvas" width="400" height="400"></canvas><p class="url" id="qr-url"></p>
      <div class="row"><button class="btn-sm" id="qr-close">ปิด</button><button class="btn-sm primary" id="qr-save">${ICON.download}บันทึกรูป</button></div>
    </dialog>`;
  bindDash(all);
}

function bindDash(all) {
  $root.querySelectorAll('[data-occ]').forEach(b => b.addEventListener('click', () => { view.occupation = b.dataset.occ; renderDash(); }));
  $root.querySelector('#inc-test').addEventListener('change', e => { view.includeTest = e.target.checked; renderDash(); });
  $root.querySelector('#xlsx').addEventListener('click', () => {
    if (!globalThis.XLSX) { alert('ไลบรารี Excel ยังโหลดไม่เสร็จ ลองอีกครั้ง'); return; }
    downloadXlsx(all);
  });
  $root.querySelector('#refresh')?.addEventListener('click', () => loadLive(session.get()));
  $root.querySelector('#logout').addEventListener('click', () => { session.clear(); view.rows = []; renderGate(); });
  $root.querySelector('#qr').addEventListener('click', openQr);
  $root.querySelector('#qr-close').addEventListener('click', () => $root.querySelector('#qr-dialog').close());
  $root.querySelector('#qr-save').addEventListener('click', () => {
    const a = document.createElement('a');
    a.download = 'survey-qr.png';
    a.href = $root.querySelector('#qr-canvas').toDataURL('image/png');
    a.click();
  });
}

function openQr() {
  if (!globalThis.qrcode) { alert('ไลบรารี QR ยังโหลดไม่เสร็จ ลองอีกครั้ง'); return; }
  const url = SURVEY_URL || new URL('index.html', location.href).href;
  const qr = globalThis.qrcode(0, 'M');
  qr.addData(url);
  qr.make();
  const canvas = $root.querySelector('#qr-canvas');
  const ctx = canvas.getContext('2d');
  const count = qr.getModuleCount();
  const quiet = 4;
  const cell = Math.floor(canvas.width / (count + quiet * 2));
  const offset = Math.floor((canvas.width - cell * count) / 2);
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#000';
  for (let r = 0; r < count; r++) for (let c = 0; c < count; c++) if (qr.isDark(r, c)) ctx.fillRect(offset + c * cell, offset + r * cell, cell, cell);
  $root.querySelector('#qr-url').textContent = url;
  $root.querySelector('#qr-dialog').showModal();
}

/* ---------------- boot ---------------- */
const saved = session.get();
if (API_URL && saved) loadLive(saved); else renderGate();
