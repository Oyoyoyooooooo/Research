// Safe localStorage wrapper: every call is no-throw (in-app browsers / private mode may throw).
const DRAFT = 'survey_draft_v3';
const PENDING = 'survey_pending_v3';

export function makeStore(storage) {
  const read = key => {
    try { const v = storage?.getItem(key); return v ? JSON.parse(v) : null; } catch { return null; }
  };
  const write = (key, val) => { try { storage?.setItem(key, JSON.stringify(val)); } catch { /* ignore */ } };
  const remove = key => { try { storage?.removeItem(key); } catch { /* ignore */ } };

  return {
    loadDraft: () => read(DRAFT),
    saveDraft: d => write(DRAFT, d),
    clearDraft: () => remove(DRAFT),
    loadPending: () => { const p = read(PENDING); return Array.isArray(p) ? p : []; },
    pushPending(row) {
      const p = this.loadPending().filter(r => r.response_id !== row.response_id);
      write(PENDING, [...p, row]);
    },
    removePending(id) { write(PENDING, this.loadPending().filter(r => r.response_id !== id)); },
  };
}

function defaultStorage() {
  try { return globalThis.localStorage; } catch { return undefined; }
}

export const store = makeStore(defaultStorage());
