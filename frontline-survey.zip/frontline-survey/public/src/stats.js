// Aggregations for the dashboard. Rows may come from the database/JSON (strings or numbers) or from toRow (numbers).
import { getQuestion } from './questions.js';
import { qKey } from './record.js';

const isOne = v => v === 1 || v === '1';
const pct = (n, d) => (d ? (n / d) * 100 : 0);

export function filterRows(rows, { occupation = 'all', includeTest = false, status } = {}) {
  return rows.filter(r =>
    (includeTest || !isOne(r.is_test)) &&
    (!status || r.status === status) &&
    (occupation === 'all' || r.q01 === occupation));
}

export function countSingle(rows, qNum) {
  const q = getQuestion(`q${qNum}`);
  const key = qKey(qNum);
  const answered = rows.filter(r => r[key] !== '' && r[key] != null);
  return q.options.map(o => {
    const n = answered.filter(r => r[key] === o.label).length;
    return { label: o.label, n, pct: pct(n, answered.length) };
  });
}

export function countMulti(rows, qNum) {
  const q = getQuestion(`q${qNum}`);
  const base = qKey(qNum);
  const answered = rows.filter(r => r[base] !== '' && r[base] != null);
  return q.options.map(o => {
    const n = answered.filter(r => isOne(r[`${base}_${o.code}`])).length;
    return { label: o.label, n, pct: pct(n, answered.length) };
  });
}

export function crosstab(rows, qA, qB) {
  const A = getQuestion(`q${qA}`).options.map(o => o.label);
  const B = getQuestion(`q${qB}`).options.map(o => o.label);
  const ka = qKey(qA), kb = qKey(qB);
  const cells = A.map(a => B.map(b => rows.filter(r => r[ka] === a && r[kb] === b).length));
  return { a: A, b: B, cells };
}

/** For a multi-select question, % of each group (single-choice question) that picked each option. */
export function crossMulti(rows, multiQ, groupQ) {
  const mq = getQuestion(`q${multiQ}`);
  const groups = getQuestion(`q${groupQ}`).options.map(o => o.label);
  const base = qKey(multiQ), gk = qKey(groupQ);
  const options = mq.options.map(o => o.label);
  const n = [], counts = [], pctRows = [];
  for (const g of groups) {
    const rs = rows.filter(r => r[gk] === g && r[base] !== '' && r[base] != null);
    const c = mq.options.map(o => rs.filter(r => isOne(r[`${base}_${o.code}`])).length);
    n.push(rs.length); counts.push(c); pctRows.push(c.map(x => pct(x, rs.length)));
  }
  return { groups, options, n, counts, pct: pctRows };
}

export function gridSummary(rows, qNum) {
  const q = getQuestion(`q${qNum}`);
  const base = qKey(qNum);
  return q.rows.map(row => {
    const counts = {};
    for (const c of q.cols) counts[c.label] = rows.filter(r => r[`${base}_${row.code}`] === c.label).length;
    return { row: row.label, counts };
  });
}

export function funnel(rows, { includeTest = false } = {}) {
  const base = filterRows(rows, { includeTest });
  const complete = base.filter(r => r.status === 'complete');
  const screened = { 1: 0, 2: 0, 3: 0, 4: 0 };
  for (const r of base) if (r.status === 'screened_out' && screened[Number(r.screened_at_q)] !== undefined) screened[Number(r.screened_at_q)]++;
  const byOccupation = {};
  for (const o of getQuestion('q1').options.filter(o => o.code !== 'other_job')) byOccupation[o.label] = complete.filter(r => r.q01 === o.label).length;
  return { complete: complete.length, screened, byOccupation };
}
