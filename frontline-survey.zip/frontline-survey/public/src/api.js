import { API_URL } from '../config.js';

const TIMEOUT_MS = 15000;

function defaultStorage() {
  try { return globalThis.localStorage; } catch { return undefined; }
}

function withTimeout(promise, ms) {
  let timer;
  return Promise.race([promise, new Promise((_, rej) => { timer = setTimeout(() => rej(new Error('timeout')), ms); })])
    .finally(() => clearTimeout(timer));
}

/** Send one response to POST {API_URL}/submit. Never throws: resolves {ok:false} on any failure. */
export async function submitRow(row, { apiUrl = API_URL, fetchImpl = globalThis.fetch, storage = defaultStorage(), hp = '' } = {}) {
  if (!apiUrl) {
    // demo mode (page opened without a server): keep it on this device only
    try {
      const list = JSON.parse(storage?.getItem('demo_submissions') || '[]');
      list.push(row);
      storage?.setItem('demo_submissions', JSON.stringify(list));
    } catch { /* demo only */ }
    return { ok: true };
  }
  try {
    const res = await withTimeout(fetchImpl(`${apiUrl}/submit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ row, hp }),
    }), TIMEOUT_MS);
    const data = await res.json();
    if (data && data.ok) return data.duplicate ? { ok: true, duplicate: true } : { ok: true };
    // 4xx (except 408/429) = the server will never accept this row: don't keep retrying it
    if (res.status >= 400 && res.status < 500 && res.status !== 408 && res.status !== 429) return { ok: false, permanent: true };
    return { ok: false };
  } catch {
    return { ok: false };
  }
}

/** Load all responses for the dashboard. The team key travels in a header, never in the URL. */
export async function fetchRows(teamKey, { apiUrl = API_URL, fetchImpl = globalThis.fetch } = {}) {
  const res = await fetchImpl(`${apiUrl}/responses`, { headers: { 'x-team-key': encodeURIComponent(teamKey || '') }, cache: 'no-store' });
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data.rows || [];
}
