// Deterministic fake responses so the team can preview the dashboard before real data exists.
import { QUESTIONS } from './questions.js';
import { toRow } from './record.js';
import { toggleMulti } from './answers.js';

function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const SAMPLE_TEXT = ['ค่าเทอมลูกขึ้นทุกปี', 'อยากให้มีประกันที่จ่ายรายวันได้', 'พ่อป่วยต้องลางานบ่อย', ''];

export function sampleRows(n, seed = 1) {
  const r = rng(seed);
  const pick = arr => arr[Math.floor(r() * arr.length)];
  const rows = [];
  for (let i = 0; i < n; i++) {
    const answers = {};
    let status = 'complete', screenedAtQ;
    for (const q of QUESTIONS) {
      if (q.showIf && !q.showIf(answers)) continue;
      if (q.screenOut) {
        // ~5% chance per screening question to answer a screen-out option
        const ok = q.options.filter(o => !q.screenOut.includes(o.code));
        const out = q.options.filter(o => q.screenOut.includes(o.code));
        answers[q.id] = (r() < 0.05 ? pick(out) : pick(ok)).code;
        if (q.screenOut.includes(answers[q.id])) { status = 'screened_out'; screenedAtQ = q.num; break; }
      } else if (q.type === 'single') {
        answers[q.id] = pick(q.options).code;
      } else if (q.type === 'multi') {
        let v = [];
        const tries = 1 + Math.floor(r() * 3);
        for (let t = 0; t < tries; t++) v = toggleMulti(q, v, pick(q.options).code).value;
        if (!v.length) v = [q.options[0].code];
        answers[q.id] = v;
        if (v.includes('other')) answers[`${q.id}_other`] = 'ไม่มีเวลาไปติดต่อ';
      } else if (q.type === 'grid') {
        answers[q.id] = Object.fromEntries(q.rows.map(row => [row.code, pick(q.cols).code]));
      } else if (q.type === 'text') {
        const t = pick(SAMPLE_TEXT);
        if (t) answers[q.id] = t;
      }
    }
    const started = Date.UTC(2026, 10, 1) + i * 3600_000;
    rows.push(toRow({ answers, status, screenedAtQ, startedAt: started, now: started + (180 + Math.floor(r() * 400)) * 1000,
      isTest: false, responseId: `sample-${seed}-${i}` }));
  }
  return rows;
}
