import { QUESTIONS, getQuestion } from './questions.js';
import { validateAnswer } from './answers.js';

export function visibleQuestions(answers) {
  return QUESTIONS.filter(q => !q.showIf || q.showIf(answers));
}

export function nextStep(currentId, answers) {
  const q = getQuestion(currentId);
  if (q.screenOut && q.screenOut.includes(answers[currentId])) {
    return { type: 'screened', atQ: q.num };
  }
  const list = visibleQuestions(answers);
  const after = list.find(x => x.num > q.num);
  return after ? { type: 'question', id: after.id } : { type: 'done' };
}

export function prevId(currentId, answers) {
  const q = getQuestion(currentId);
  const before = visibleQuestions(answers).filter(x => x.num < q.num);
  return before.length ? before[before.length - 1].id : null;
}

export function progress(currentId, answers) {
  const list = visibleQuestions(answers);
  return { index: list.findIndex(x => x.id === currentId) + 1, total: list.length };
}

/** First reason a set of answers can't be submitted as complete: a screen-out answer or a missing required answer. */
export function firstProblem(answers) {
  for (const q of visibleQuestions(answers)) {
    if (q.screenOut && q.screenOut.includes(answers[q.id])) return { type: 'screened', id: q.id };
    if (!validateAnswer(q, answers[q.id], answers).ok) return { type: 'missing', id: q.id };
  }
  return null;
}

/* ---------- pages (one scrolling page per section; screening q1-q4 share the first page) ---------- */
export const PAGES = (() => {
  const pages = [];
  let lastSection = null;
  for (const q of QUESTIONS) {
    const screening = !!q.screenOut;
    const key = screening ? 'screening' : q.section;
    if (key !== lastSection) { pages.push([]); lastSection = key; }
    pages[pages.length - 1].push(q.id);
  }
  return pages;
})();

export const pageIndexOf = id => PAGES.findIndex(p => p.includes(id));

export function pageQuestions(index, answers) {
  return PAGES[index].map(getQuestion).filter(q => !q.showIf || q.showIf(answers));
}

/** Every required question on the page that isn't answered properly, in page order. */
export function pageProblems(index, answers) {
  const out = [];
  for (const q of pageQuestions(index, answers)) {
    const r = validateAnswer(q, answers[q.id], answers);
    if (!r.ok) out.push({ id: q.id, message: r.message });
  }
  return out;
}

/** First question on the page whose answer ends the survey, or null. */
export function pageScreenOut(index, answers) {
  return pageQuestions(index, answers).find(q => q.screenOut && q.screenOut.includes(answers[q.id])) || null;
}
