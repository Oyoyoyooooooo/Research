// Pure validation used by the server (lib/handlers.js). Kept dependency-free
// so the sample-data generator can use it in the browser too.
export function validateRow(row, schema) {
  if (!row || typeof row !== 'object') return { ok: false, error: 'invalid' };
  var id = row.response_id;
  if (typeof id !== 'string' || !id || id.length > 64) return { ok: false, error: 'bad_id' };
  if (row.status !== 'complete' && row.status !== 'screened_out') return { ok: false, error: 'bad_status' };
  var clean = {};
  for (var i = 0; i < schema.columns.length; i++) {
    var key = schema.columns[i];
    var kind = schema.kinds[key];
    var v = row[key];
    if (v === undefined || v === null || v === '') { clean[key] = ''; continue; }
    if (kind === 'system') {
      var s = String(v);
      var okSys =
        key === 'response_id' ? /^[A-Za-z0-9-]{1,64}$/.test(s) :
        key === 'status' ? true :
        key === 'submitted_at' ? /^[0-9T:.+\-Z]{10,40}$/.test(s) :
        key === 'screened_at_q' ? /^[1-4]$/.test(s) :
        key === 'is_test' ? /^[01]$/.test(s) :
        key === 'duration_sec' ? /^[0-9]{1,7}$/.test(s) : false;
      if (!okSys) return { ok: false, error: 'bad_value:' + key };
      clean[key] = s;
    } else if (kind === 'flag') {
      if (v !== 0 && v !== 1) return { ok: false, error: 'bad_value:' + key };
      clean[key] = v;
    } else if (kind === 'text' || kind === 'other_text') {
      var t = String(v).trim().slice(0, 1000);
      if (/^[=+\-@]/.test(t)) t = "'" + t;
      clean[key] = t;
    } else if (kind === 'multi_joined') {
      var parts = String(v).split(', ');
      for (var j = 0; j < parts.length; j++) {
        if (schema.allowed[key].indexOf(parts[j]) < 0) return { ok: false, error: 'bad_value:' + key };
      }
      clean[key] = String(v);
    } else {
      if (schema.allowed[key].indexOf(v) < 0) return { ok: false, error: 'bad_value:' + key };
      clean[key] = v;
    }
  }
  return { ok: true, clean: clean };
}
