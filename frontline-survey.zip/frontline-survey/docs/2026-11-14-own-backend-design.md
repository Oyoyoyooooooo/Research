# Design (เพิ่มเติม): เปลี่ยนจาก Google Sheet เป็นเว็บของทีมเอง (Vercel + Neon Postgres)

วันที่: 2026-11-14 · ต่อยอดจาก `docs/2026-11-14-frontline-survey-web-design.md` (ทุกอย่างเรื่องคำถาม, UX, ความเป็นส่วนตัว, Dashboard ยังเหมือนเดิม)

## เหตุผล
ผู้ใช้ไม่ต้องการพึ่ง Google Sheet อยากให้ทุกอย่าง (ฟอร์ม + ระบบรับคำตอบ + ฐานข้อมูล + Dashboard) อยู่ในโปรเจกต์เดียวของทีม เพื่อให้ทำต่อ/แก้ต่อได้ง่าย

## แนวทาง (Approaches)
| แนวทาง | สรุป |
|---|---|
| **A. Vercel + Neon Postgres (เลือก)** | ฟรี ข้อมูลถาวร push GitHub แล้ว deploy เอง API เป็นไฟล์ JS ใน `api/` |
| B. Node + SQLite บน Railway/Fly | ง่ายสุดแต่ต้องมี disk ถาวร (~150-200 บาท/เดือน) |
| C. รันในเครื่องทีม + tunnel | ตัดทิ้ง เครื่องปิด = ฟอร์มล่ม |

## สิ่งที่เปลี่ยน
- **โครงสร้าง:** `public/` = หน้าเว็บทั้งหมด (index, dashboard, css, src) · `api/` = ระบบรับคำตอบ · `lib/` = โค้ดฝั่งเซิร์ฟเวอร์ (ฐานข้อมูล) · `vercel.json` ให้เผยแพร่เฉพาะ `public/` (docs/tests ไม่ขึ้นเว็บ)
- **API (same origin, ไม่มีปัญหา CORS):**
  - `POST /api/submit` — รับ `{row, hp}` → ตรวจด้วย `validateRow` ตัวเดิม (import ตรง ไม่ต้อง generate แล้ว) → บันทึก, `response_id` ซ้ำ = ไม่บันทึกซ้ำ (`ON CONFLICT DO NOTHING`), เวลาส่งใช้เวลาเซิร์ฟเวอร์ (Asia/Bangkok) จำกัดขนาด body 20KB
  - `GET /api/responses` — ต้องส่ง header `x-team-key` (ไม่ใส่ใน URL) เทียบกับ env `TEAM_KEY` แบบ constant-time → คืนแถวทั้งหมดเรียงตามเวลา
- **ฐานข้อมูล:** ตาราง `responses(response_id text primary key, submitted_at timestamptz, status text, is_test boolean, data jsonb)` — เก็บทั้งแถวเป็น JSON ทำให้เพิ่ม/แก้คำถามภายหลังไม่ต้องแก้ตาราง สร้างตารางอัตโนมัติครั้งแรก (`CREATE TABLE IF NOT EXISTS`) ใช้ไลบรารี `@neondatabase/serverless`
- **รันในเครื่อง (ไม่ต้องสมัครอะไร):** `npm run dev` เปิดเว็บ + API ที่ localhost โดยใช้ไฟล์ `.data/responses.json` แทนฐานข้อมูลเมื่อไม่มี `DATABASE_URL` → ทีมลองครบทุกฟีเจอร์ได้ก่อนขึ้นเว็บจริง
- **Dashboard:** หน้าเดิม เปลี่ยนแค่ช่องทางโหลดข้อมูลไปที่ `/api/responses` ปุ่ม Excel / QR / ข้อมูลตัวอย่างเหมือนเดิม
- **ลบ:** `apps-script/`, `tools/build-schema.mjs`, `tools/build-dist.mjs`, ข้อความเรื่อง Google Sheet ใน SETUP และหน้าเว็บ
- **SETUP.md ใหม่:** สมัคร GitHub → อัปโหลดโปรเจกต์ → Vercel Import → Storage: สร้าง Neon (ได้ `DATABASE_URL` อัตโนมัติ) → ตั้ง `TEAM_KEY` → Deploy → ทดสอบ `?test=1` → QR

## ความเป็นส่วนตัว
- ไม่เก็บ IP / ชื่อ / อีเมลลงฐานข้อมูล (Vercel มี request log ชั่วคราวของแพลตฟอร์มเอง ระบุไว้ใน SETUP)
- รหัสทีมอยู่ใน env ของ Vercel เท่านั้น ไม่อยู่ในโค้ด

## ปล่อยให้ผู้สร้างตัดสิน
- รายละเอียดโค้ด adapter ฐานข้อมูล, ข้อความ error, การจัดไฟล์ภายใน `lib/`
