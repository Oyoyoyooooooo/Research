# Own Backend (Vercel + Neon) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans (chosen: Native). Steps use checkbox (`- [ ]`) syntax.

**Goal:** Replace the Google Apps Script/Sheet backend with the team's own API (`/api/submit`, `/api/responses`) on Vercel, storing rows in Neon Postgres, runnable locally with a JSON-file store.

**Architecture:** Site moves to `public/` (published alone via `vercel.json`). Pure request handlers in `lib/handlers.js` are shared by Vercel functions (`api/*.js`) and the local dev server (`tools/serve.mjs`). A `store` interface has two implementations: Neon (when `DATABASE_URL` set) and a JSON file (`.data/responses.json`) for local dev.

**Tech Stack:** Node 26 ESM, Vercel Node functions, `@neondatabase/serverless@1.2.0` (exact pin), existing vanilla front-end, `node --test`.

**Spec:** `docs/2026-11-14-own-backend-design.md` (+ original `docs/2026-11-14-frontline-survey-web-design.md`).

## Global Constraints
- Never store IP, name, email; team key only from env `TEAM_KEY`, compared with `crypto.timingSafeEqual`, sent in header `x-team-key` (never in URL).
- Request body limit 20 KB → 413. `submitted_at` set by server, ISO with +07:00.
- Duplicate `response_id` → `{ok:true, duplicate:true}`, no second row. Honeypot non-empty → `{ok:true}` without storing.
- Only `public/` is published (`vercel.json` `outputDirectory: "public"`).
- All existing tests keep passing (paths updated).

## Review Focus
1. Missing `TEAM_KEY` env → `/api/responses` must refuse (never "empty key matches empty key"). Test in Task 3.
2. Concurrent duplicate submits → one row (primary key + ON CONFLICT; file store checks under a single write). Test in Task 2.
3. Malformed/non-JSON/oversized body → 400/413 JSON, never 500 stack trace. Test in Task 3.
4. Old Google-Sheet wording left in UI/SETUP → none. Grep check in Task 5.
5. Dashboard rows from Postgres jsonb keep numbers as numbers; stats already coerce strings. Covered by existing stats tests + Task 3 list test.

---

### Task 1: Move site into `public/`
**Files:** move `index.html dashboard.html styles.css dashboard.css config.js src/` → `public/`; update test imports `../src/` → `../public/src/`, `tools/schema-data.mjs` → `lib/schema.js` (imports `../public/src/...`); create `vercel.json` `{ "outputDirectory": "public", "buildCommand": "", "framework": null }`; `tools/serve.mjs` root → `public/`.
- [ ] Move files; run `npm test` → Expected: all pass except tests referring to removed build tools (delete `tests/schema.test.mjs`, `tests/dist.test.mjs`, `tools/build-*.mjs`, `apps-script/`).

### Task 2: Store (`lib/store.js`)
**Interfaces — Produces:** `makeStore({databaseUrl, filePath}) → {insert(row): Promise<'inserted'|'duplicate'>, list(): Promise<Row[]>}`; Neon impl creates table on first use: `responses(response_id text primary key, submitted_at timestamptz not null, status text not null, is_test boolean not null default false, data jsonb not null)`; `list()` returns `data` objects ordered by `submitted_at`.
- [ ] Test `tests/store.test.mjs` (file store in a temp dir): insert → 'inserted'; same id → 'duplicate'; `Promise.all` of two inserts same id → exactly one row; list order by submitted_at; numbers preserved.
- [ ] Run → FAIL; implement; run → PASS.

### Task 3: Handlers (`lib/handlers.js`)
**Produces:** `handleSubmit(rawBody: string, {store, now}) → {status, body}`; `handleList(headers, {store, teamKey}) → {status, body}`.
- [ ] Tests `tests/handlers.test.mjs`: valid row → 200 `{ok:true}` and stored with server `submitted_at` ending `+07:00`; duplicate → `{ok:true,duplicate:true}`; hp → `{ok:true}` nothing stored; non-JSON → 400 `{ok:false,error:'bad_json'}`; invalid label → 400; body > 20 KB → 413; list with right key → 200 `{rows}`; wrong key → 401 `{error:'bad_key'}`; teamKey undefined/'' → 401 even with empty header.
- [ ] Run → FAIL; implement; run → PASS.

### Task 4: Wire Vercel functions + dev server + client
**Files:** `api/submit.js`, `api/responses.js` (read raw body from `req`, call handlers, `store` from `makeStore({databaseUrl: process.env.DATABASE_URL})`); `tools/serve.mjs` routes `POST /api/submit`, `GET /api/responses` to the same handlers with file store `.data/responses.json` and `TEAM_KEY` default `dev` (printed at start); `package.json` add dependency `@neondatabase/serverless: "1.2.0"`, script `dev`; `public/config.js` `API_URL = '/api'`; `public/src/api.js` → POST `${API_URL}/submit`, GET `${API_URL}/responses` with header; update `tests/api.test.mjs` expectations.
- [ ] Update api tests (URL + header) → FAIL; implement → PASS.
- [ ] Browser: `npm run dev`, full survey run → row in `.data/responses.json`; dashboard with key `dev` shows it; wrong key shows error; Excel export works.

### Task 5: Copy cleanup, SETUP rewrite, final review
- [ ] Replace Google Sheet wording in `public/` (demo banner, dashboard gate) — `grep -ri "google sheet\|apps script" public` → no hits.
- [ ] Rewrite `SETUP.md` (GitHub → Vercel import → Storage Neon → TEAM_KEY → deploy → test `?test=1` → QR → Excel; local `npm install && npm run dev`; privacy).
- [ ] `.gitignore` (`node_modules`, `.data`, `.vercel`, `.env*`).
- [ ] `npm test` all pass; fresh-context final review; fix Critical/Important.
