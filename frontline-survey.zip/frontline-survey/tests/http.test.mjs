import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { readBody, sendJson } from '../lib/http.js';
import { MAX_BODY_BYTES } from '../lib/handlers.js';

test('oversized body still gets a JSON reply (no dropped connection)', async () => {
  const srv = createServer(async (req, res) => {
    const body = await readBody(req);
    sendJson(res, { status: body.length > MAX_BODY_BYTES ? 413 : 200, body: { len: body.length } });
  });
  await new Promise(r => srv.listen(0, r));
  const url = `http://127.0.0.1:${srv.address().port}/`;
  try {
    const big = await fetch(url, { method: 'POST', body: 'x'.repeat(200_000) });
    assert.equal(big.status, 413);
    const small = await fetch(url, { method: 'POST', body: '{"a":1}' });
    assert.deepEqual(await small.json(), { len: 7 });
  } finally { srv.close(); }
});
