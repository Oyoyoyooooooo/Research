import test from 'node:test';
import assert from 'node:assert/strict';
import { validateRow } from '../public/src/server-validate.js';
import { buildSchema } from '../lib/schema.js';
import { toRow } from '../public/src/record.js';
import { FULL } from './fixtures.mjs';

const schema = buildSchema();
const good = () => toRow({ answers: FULL, status: 'complete', startedAt: 0, now: 60000, isTest: false, responseId: 'abc' });

test('accepts a valid full row', () => {
  const r = validateRow(good(), schema);
  assert.equal(r.ok, true);
  assert.equal(r.clean.q01, 'รปภ.');
});

test('rejects missing id and bad status', () => {
  assert.equal(validateRow({ ...good(), response_id: '' }, schema).ok, false);
  assert.equal(validateRow({ ...good(), response_id: 'x'.repeat(65) }, schema).ok, false);
  assert.equal(validateRow({ ...good(), status: 'hacked' }, schema).ok, false);
});

test('rejects label not in allowed list', () => {
  assert.equal(validateRow({ ...good(), q01: 'ผู้จัดการ' }, schema).ok, false);
  assert.equal(validateRow({ ...good(), q18: 'ภาระหนี้, ปลอม' }, schema).ok, false);
  assert.equal(validateRow({ ...good(), q18_child: 7 }, schema).ok, false);
});

test('drops unknown keys', () => {
  const r = validateRow({ ...good(), evil: 'x' }, schema);
  assert.equal('evil' in r.clean, false);
});

test('neutralises formula-like free text and keeps punctuation', () => {
  const r = validateRow({ ...good(), q33: '=SUM(A1)', q27_other_text: '+1' }, schema);
  assert.equal(r.clean.q33, "'=SUM(A1)");
  assert.equal(r.clean.q27_other_text, "'+1");
  const r2 = validateRow({ ...good(), q33: 'a, "b"\nc' }, schema);
  assert.equal(r2.clean.q33, 'a, "b"\nc');
});

test('trims long text to 1000 chars', () => {
  const r = validateRow({ ...good(), q33: 'ก'.repeat(1500) }, schema);
  assert.equal(r.clean.q33.length, 1000);
});

test('system columns are strictly validated', () => {
  assert.equal(validateRow({ ...good(), response_id: '=HYPERLINK("x")' }, schema).ok, false);
  assert.equal(validateRow({ ...good(), is_test: '=1+1' }, schema).ok, false);
  assert.equal(validateRow({ ...good(), screened_at_q: '@x' }, schema).ok, false);
  assert.equal(validateRow({ ...good(), duration_sec: -5 }, schema).ok, false);
  assert.equal(validateRow({ ...good(), status: 'screened_out', screened_at_q: 3 }, schema).ok, true);
  assert.equal(validateRow({ ...good(), screened_at_q: '9' }, schema).ok, false);
  const ok = validateRow({ ...good(), response_id: '0f8fad5b-d9cb-469f-a165-70867728950e', is_test: '1', duration_sec: '42' }, schema);
  assert.equal(ok.ok, true);
});
