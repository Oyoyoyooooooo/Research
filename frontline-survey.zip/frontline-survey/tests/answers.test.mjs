import test from 'node:test';
import assert from 'node:assert/strict';
import { getQuestion } from '../public/src/questions.js';
import { toggleMulti, validateAnswer, pruneHidden } from '../public/src/answers.js';

const q18 = getQuestion('q18');
const q22 = getQuestion('q22');

test('max 2 blocks a third pick', () => {
  assert.deepEqual(toggleMulti(q18, ['child', 'parent'], 'debt'), { value: ['child', 'parent'], blocked: true });
});

test('toggle off removes', () => {
  assert.deepEqual(toggleMulti(q18, ['child', 'parent'], 'child'), { value: ['parent'], blocked: false });
});

test('exclusive replaces others even when full', () => {
  assert.deepEqual(toggleMulti(q22, ['savings', 'family'], 'unsure'), { value: ['unsure'], blocked: false });
});

test('picking a normal option clears exclusive', () => {
  assert.deepEqual(toggleMulti(q22, ['unsure'], 'savings'), { value: ['savings'], blocked: false });
});

test('two exclusives replace each other', () => {
  assert.deepEqual(toggleMulti(getQuestion('q24'), ['none'], 'unsure'), { value: ['unsure'], blocked: false });
});

test('required single/multi', () => {
  assert.deepEqual(validateAnswer(getQuestion('q1'), undefined, {}), { ok: false, message: 'กรุณาเลือกคำตอบ' });
  assert.deepEqual(validateAnswer(q18, [], {}), { ok: false, message: 'กรุณาเลือกคำตอบ' });
  assert.deepEqual(validateAnswer(q18, ['child'], {}), { ok: true });
});

test('grid must be complete', () => {
  const q19 = getQuestion('q19');
  assert.deepEqual(validateAnswer(q19, { hosp: 'yes', accident: 'no', unpaid: 'na' }, {}),
    { ok: false, message: 'กรุณาตอบให้ครบทุกแถว' });
  assert.deepEqual(validateAnswer(q19, { hosp: 'yes', accident: 'no', unpaid: 'na', cut: 'no' }, {}), { ok: true });
});

test('optional text and empty other text are ok', () => {
  assert.deepEqual(validateAnswer(getQuestion('q33'), '', {}), { ok: true });
  assert.deepEqual(validateAnswer(getQuestion('q27'), ['other'], { q27_other: '' }), { ok: true });
});

test('pruneHidden drops q29 and stray other text', () => {
  const out = pruneHidden({ q28: ['none'], q29: '5', q27: ['expensive'], q27_other: 'x' });
  assert.equal('q29' in out, false);
  assert.equal('q27_other' in out, false);
  assert.deepEqual(out.q28, ['none']);
  const keep = pruneHidden({ q27: ['other'], q27_other: 'x' });
  assert.equal(keep.q27_other, 'x');
});
