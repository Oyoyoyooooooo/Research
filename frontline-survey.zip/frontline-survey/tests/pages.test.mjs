import test from 'node:test';
import assert from 'node:assert/strict';
import { PAGES, pageIndexOf, pageQuestions, pageProblems, pageScreenOut } from '../public/src/flow.js';
import { FULL } from './fixtures.mjs';

test('7 pages: screening q1-q4 together, then one page per section', () => {
  assert.equal(PAGES.length, 7);
  assert.deepEqual(PAGES[0], ['q1', 'q2', 'q3', 'q4']);
  assert.deepEqual(PAGES[1], ['q5', 'q6', 'q7', 'q8', 'q9', 'q10']);
  assert.equal(PAGES.flat().length, 33);
  assert.equal(pageIndexOf('q2'), 0);
  assert.equal(pageIndexOf('q29'), 6);
});

test('pageQuestions hides q29 when q28 is none', () => {
  assert.ok(pageQuestions(6, { q28: ['a'] }).some(q => q.id === 'q29'));
  assert.ok(!pageQuestions(6, { q28: ['none'] }).some(q => q.id === 'q29'));
});

test('pageProblems lists every unanswered required question on the page, in order', () => {
  assert.deepEqual(pageProblems(0, { q2: '30_35' }).map(p => p.id), ['q1', 'q3', 'q4']);
  assert.deepEqual(pageProblems(1, FULL), []);
  const p = pageProblems(pageIndexOf('q19'), { ...FULL, q19: { hosp: 'yes' } });
  assert.deepEqual(p, [{ id: 'q19', message: 'กรุณาตอบให้ครบทุกแถว' }]);
});

test('pageScreenOut returns the first screen-out answer on the page', () => {
  assert.equal(pageScreenOut(0, { q1: 'maid', q2: 'gt45', q3: 'no', q4: 'both' }).id, 'q2');
  assert.equal(pageScreenOut(0, { q1: 'maid', q2: '30_35', q3: 'yes', q4: 'both' }), null);
});
