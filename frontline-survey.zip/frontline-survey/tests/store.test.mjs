import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { makeFileStore, makeNeonStore } from '../lib/store.js';

const row = (id, at, extra = {}) => ({ response_id: id, submitted_at: at, status: 'complete', is_test: '0', duration_sec: 120, q01: 'รปภ.', ...extra });

function tempStore() {
  const dir = mkdtempSync(join(tmpdir(), 'store-'));
  return { store: makeFileStore(join(dir, 'sub', 'responses.json')), cleanup: () => rmSync(dir, { recursive: true, force: true }) };
}

test('file store inserts, dedupes and lists in time order', async () => {
  const { store, cleanup } = tempStore();
  try {
    assert.deepEqual(await store.list(), []);
    assert.equal(await store.insert(row('b', '2026-11-14T10:00:00+07:00')), 'inserted');
    assert.equal(await store.insert(row('a', '2026-11-14T09:00:00+07:00')), 'inserted');
    assert.equal(await store.insert(row('a', '2026-11-14T11:00:00+07:00')), 'duplicate');
    const list = await store.list();
    assert.deepEqual(list.map(r => r.response_id), ['a', 'b']);
    assert.equal(list[0].duration_sec, 120);
  } finally { cleanup(); }
});

test('file store: concurrent duplicate inserts store one row', async () => {
  const { store, cleanup } = tempStore();
  try {
    const res = await Promise.all([store.insert(row('x', '2026-11-14T10:00:00+07:00')), store.insert(row('x', '2026-11-14T10:00:00+07:00'))]);
    assert.deepEqual(res.sort(), ['duplicate', 'inserted']);
    assert.equal((await store.list()).length, 1);
  } finally { cleanup(); }
});

test('neon store: creates table once, maps rowCount to inserted/duplicate, lists data', async () => {
  const calls = [];
  let rowCount = 1;
  const sql = {
    // mimics neon(url).query(text, params, { fullResults: true })
    query: async (text, params, opts) => {
      assert.equal(opts?.fullResults, true);
      calls.push(text.replace(/\s+/g, ' ').trim());
      if (/^select/i.test(text.trim())) return { rows: [{ data: row('z', '2026-11-14T10:00:00+07:00') }], rowCount: 1 };
      if (/insert/i.test(text)) return { rows: [], rowCount };
      return { rows: [], rowCount: 0 };
    },
  };
  const store = makeNeonStore(sql);
  assert.equal(await store.insert(row('z', '2026-11-14T10:00:00+07:00')), 'inserted');
  rowCount = 0;
  assert.equal(await store.insert(row('z', '2026-11-14T10:00:00+07:00')), 'duplicate');
  const list = await store.list();
  assert.equal(list[0].response_id, 'z');
  assert.equal(calls.filter(c => /create table/i.test(c)).length, 1);
  assert.ok(calls.some(c => /on conflict \(response_id\) do nothing/i.test(c)));
});

test('neon store: a failed CREATE TABLE is retried on the next request', async () => {
  let creates = 0;
  const sql = { query: async (text) => {
    if (/create table/i.test(text)) { creates++; if (creates === 1) throw new Error('network'); return { rows: [], rowCount: 0 }; }
    return { rows: [], rowCount: 1 };
  } };
  const store = makeNeonStore(sql);
  await assert.rejects(store.insert(row('a', '2026-11-14T10:00:00+07:00')));
  assert.equal(await store.insert(row('a', '2026-11-14T10:00:00+07:00')), 'inserted');
  assert.equal(creates, 2);
});

test('neon store: concurrent CREATE race (42P07/23505) is ignored', async () => {
  const sql = { query: async (text) => {
    if (/create table/i.test(text)) throw Object.assign(new Error('dup'), { code: '23505' });
    return { rows: [], rowCount: 1 };
  } };
  assert.equal(await makeNeonStore(sql).insert(row('a', '2026-11-14T10:00:00+07:00')), 'inserted');
});

test('storeFromEnv on Vercel without DATABASE_URL gives no store', async () => {
  const { storeFromEnv } = await import('../lib/store.js');
  assert.equal(await storeFromEnv({ VERCEL: '1' }, { fresh: true }), null);
});
