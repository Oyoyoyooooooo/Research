import test from 'node:test';
import assert from 'node:assert/strict';
import { QUESTIONS, SECTIONS, getQuestion, INTRO_TEXT, THANKS_TEXT } from '../public/src/questions.js';

test('has 33 questions numbered in order', () => {
  assert.equal(QUESTIONS.length, 33);
  QUESTIONS.forEach((q, i) => {
    assert.equal(q.num, i + 1);
    assert.equal(q.id, `q${i + 1}`);
  });
});

test('has 10 sections and every question belongs to one', () => {
  assert.equal(SECTIONS.length, 10);
  const ids = new Set(SECTIONS.map(s => s.id));
  for (const q of QUESTIONS) assert.ok(ids.has(q.section), q.id);
});

test('options are unique and at most 9', () => {
  for (const q of QUESTIONS) {
    if (q.type === 'single' || q.type === 'multi') {
      assert.ok(q.options.length <= 9, q.id);
      assert.equal(new Set(q.options.map(o => o.code)).size, q.options.length, q.id);
    }
  }
});

test('grids have 4 rows x 3 cols', () => {
  const q19 = getQuestion('q19');
  assert.equal(q19.type, 'grid');
  assert.equal(q19.rows.length, 4);
  assert.deepEqual(q19.cols.map(c => c.label), ['เคย', 'ไม่เคย', 'ไม่ขอตอบ']);
  const q20 = getQuestion('q20');
  assert.equal(q20.rows.length, 4);
  assert.deepEqual(q20.cols.map(c => c.label), ['ต่ำ', 'ปานกลาง', 'สูง']);
});

test('max 2 only on q18 q22 q28 q32', () => {
  const withMax = QUESTIONS.filter(q => q.max).map(q => [q.id, q.max]);
  assert.deepEqual(withMax, [['q18', 2], ['q22', 2], ['q28', 2], ['q32', 2]]);
});

test('only q33 is optional', () => {
  assert.deepEqual(QUESTIONS.filter(q => !q.required).map(q => q.id), ['q33']);
});

test('screen-out codes', () => {
  assert.deepEqual(getQuestion('q1').screenOut, ['other_job']);
  assert.deepEqual(getQuestion('q2').screenOut, ['lt30', 'gt45']);
  assert.deepEqual(getQuestion('q3').screenOut, ['no']);
  assert.deepEqual(getQuestion('q4').screenOut, ['no']);
  assert.equal(QUESTIONS.filter(q => q.screenOut).length, 4);
});

test('exclusive options', () => {
  const ex = id => getQuestion(id).options.filter(o => o.exclusive).map(o => o.label);
  assert.deepEqual(ex('q15'), ['ไม่มี', 'ไม่แน่ใจ']);
  assert.deepEqual(ex('q22'), ['ไม่แน่ใจ']);
  assert.deepEqual(ex('q24'), ['ไม่มีเลย', 'ไม่แน่ใจ']);
  assert.deepEqual(ex('q28').length, 1);
  assert.ok(ex('q28')[0].startsWith('ไม่สนใจข้อไหนเลย'));
  assert.equal(getQuestion('q28').options.find(o => o.exclusive).code, 'none');
  const total = QUESTIONS.flatMap(q => q.options || []).filter(o => o.exclusive).length;
  assert.equal(total, 6);
});

test('q27 has exactly one free-text other option', () => {
  const others = QUESTIONS.flatMap(q => (q.options || []).filter(o => o.other).map(() => q.id));
  assert.deepEqual(others, ['q27']);
});

test('verbatim spot checks', () => {
  assert.ok(getQuestion('q16').text.includes('ครอบครัวจะอยู่ได้นานแค่ไหน'));
  assert.deepEqual(getQuestion('q7').options.map(o => o.label),
    ['ต่ำกว่า 9,000', '9,000-12,000', '12,001-15,000', '15,001-20,000', 'มากกว่า 20,000 บาท']);
  assert.ok(INTRO_TEXT.includes('นายจ้างและบริษัทไม่เห็นคำตอบ'));
  assert.equal(THANKS_TEXT, 'ขอบคุณที่ตอบแบบสำรวจ ข้อมูลของคุณไม่ระบุตัวตน');
});

test('q29 hidden only when q28 is exactly none', () => {
  const q29 = getQuestion('q29');
  assert.equal(q29.showIf({ q28: ['none'] }), false);
  assert.equal(q29.showIf({ q28: ['a'] }), true);
  assert.equal(q29.showIf({}), true);
});

import { splitHint } from '../public/src/questions.js';

test('splitHint pulls answer-instructions out of the title, keeps real content', () => {
  assert.deepEqual(splitHint('เรื่องไหนที่คุณกังวลที่สุด (เลือกไม่เกิน 2 ข้อ)'), { title: 'เรื่องไหนที่คุณกังวลที่สุด', hint: '' });
  assert.deepEqual(splitHint('ประกันหรือสิทธิที่คุณมีอยู่ตอนนี้ (เลือกได้หลายข้อ)'), { title: 'ประกันหรือสิทธิที่คุณมีอยู่ตอนนี้', hint: 'เลือกได้หลายข้อ' });
  assert.deepEqual(splitHint('(ไม่บังคับ) มีอะไรอยากบอกเพิ่ม'), { title: 'มีอะไรอยากบอกเพิ่ม', hint: 'ไม่ตอบก็ได้' });
  assert.equal(splitHint('อายุลูกคนเล็ก (หรือหลานที่เลี้ยง)').title, 'อายุลูกคนเล็ก (หรือหลานที่เลี้ยง)');
  assert.deepEqual(splitHint('ถ้าพรุ่งนี้ ... นานแค่ไหน (ตอบตามความรู้สึก)'), { title: 'ถ้าพรุ่งนี้ ... นานแค่ไหน', hint: 'ตอบตามความรู้สึก' });
  assert.equal(splitHint('ข้อ (เลือก 1 ข้อ)').hint, '');
});
