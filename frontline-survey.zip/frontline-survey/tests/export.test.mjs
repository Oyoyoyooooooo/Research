import test from 'node:test';
import assert from 'node:assert/strict';
import { workbookData } from '../public/src/export-xlsx.js';
import { crossMulti } from '../public/src/stats.js';
import { buildColumns, toRow } from '../public/src/record.js';
import { FULL } from './fixtures.mjs';

const meta = { startedAt: 0, now: 90000, isTest: false };
const sheetRow = obj => Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, String(v)]));

test('responses sheet: header + rows, numbers typed, text kept as text', () => {
  const r = sheetRow(toRow({ answers: { ...FULL, q33: "'=SUM(A1)" }, status: 'complete', responseId: 'a', ...meta }));
  const wb = workbookData([r]);
  const keys = buildColumns().map(c => c.key);
  assert.deepEqual(wb.responses[0], keys);
  const row = wb.responses[1];
  assert.equal(row[keys.indexOf('duration_sec')], 90);
  assert.equal(row[keys.indexOf('q18_child')], 1);
  assert.equal(row[keys.indexOf('screened_at_q')], '');
  assert.equal(row[keys.indexOf('q33')], "'=SUM(A1)");
  assert.equal(typeof row[keys.indexOf('q01')], 'string');
});

test('codebook and summary sheets exist', () => {
  const wb = workbookData([]);
  assert.equal(wb.codebook.length, buildColumns().length + 1);
  assert.ok(wb.summary.length > 1);
  assert.deepEqual(wb.summary[0], ['รายการ', 'จำนวน']);
});

test('crossMulti: share of each group choosing each option', () => {
  const a = toRow({ answers: { ...FULL, q1: 'guard', q28: ['a', 'b'] }, status: 'complete', responseId: '1', ...meta });
  const b = toRow({ answers: { ...FULL, q1: 'guard', q28: ['a'] }, status: 'complete', responseId: '2', ...meta });
  const c = toRow({ answers: { ...FULL, q1: 'maid', q28: ['c'] }, status: 'complete', responseId: '3', ...meta });
  const t = crossMulti([a, b, c], 28, 1);
  const gi = t.groups.indexOf('รปภ.');
  assert.equal(t.n[gi], 2);
  assert.equal(t.pct[gi][0], 100); // A chosen by both guards
  assert.equal(t.pct[gi][1], 50);
  assert.equal(t.pct[t.groups.indexOf('ภารโรง')][0], 0);
});
