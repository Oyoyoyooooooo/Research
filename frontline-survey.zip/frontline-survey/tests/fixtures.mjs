export const FULL = {
  q1: 'guard', q2: '36_40', q3: 'yes', q4: 'both', q5: 'outsource', q6: 'daily', q7: '9_12k', q8: 'single',
  q9: 'diff', q10: 'na', q11: '6_12', q12: '2_4k', q13: '1_3k', q14: 'none', q15: ['ucs', 'sso'],
  q16: '1_2w', q17: 'child', q18: ['child', 'debt'],
  q19: { hosp: 'yes', accident: 'no', unpaid: 'na', cut: 'yes' },
  q20: { self: 'high', parent: 'mid', child: 'low', job: 'high' },
  q21: 'self_sick', q22: ['family', 'pawn'], q23: 'none', q24: ['ucs'], q25: 'lt1w', q26: 'line_only',
  q27: ['expensive', 'other'], q27_other: 'ไม่มีเวลา', q28: ['c', 'd'], q29: '4', q30: '100_200',
  q31: 'daily_weekly', q32: ['line', 'store'], q33: 'สวัสดี, "ครับ"\nบรรทัดสอง',
};
