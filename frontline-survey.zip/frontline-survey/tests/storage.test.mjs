import test from 'node:test';
import assert from 'node:assert/strict';
import { makeStore } from '../public/src/storage.js';

function memStorage() {
  const m = new Map();
  return { getItem: k => (m.has(k) ? m.get(k) : null), setItem: (k, v) => m.set(k, String(v)), removeItem: k => m.delete(k) };
}
const throwing = { getItem() { throw new Error('x'); }, setItem() { throw new Error('x'); }, removeItem() { throw new Error('x'); } };

test('draft roundtrip and clear', () => {
  const s = makeStore(memStorage());
  assert.equal(s.loadDraft(), null);
  s.saveDraft({ answers: { q1: 'maid' }, current: 'q2' });
  assert.deepEqual(s.loadDraft(), { answers: { q1: 'maid' }, current: 'q2' });
  s.clearDraft();
  assert.equal(s.loadDraft(), null);
});

test('pending queue dedupes by response_id', () => {
  const s = makeStore(memStorage());
  s.pushPending({ response_id: 'a' });
  s.pushPending({ response_id: 'a' });
  s.pushPending({ response_id: 'b' });
  assert.deepEqual(s.loadPending().map(r => r.response_id), ['a', 'b']);
  s.removePending('a');
  assert.deepEqual(s.loadPending().map(r => r.response_id), ['b']);
});

test('throwing storage never throws', () => {
  const s = makeStore(throwing);
  assert.equal(s.loadDraft(), null);
  assert.doesNotThrow(() => s.saveDraft({}));
  assert.doesNotThrow(() => s.pushPending({ response_id: 'a' }));
  assert.deepEqual(s.loadPending(), []);
});

test('missing storage never throws', () => {
  const s = makeStore(undefined);
  assert.equal(s.loadDraft(), null);
  assert.doesNotThrow(() => s.clearDraft());
});
