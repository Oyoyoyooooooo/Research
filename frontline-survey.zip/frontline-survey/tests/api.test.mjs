import test from 'node:test';
import assert from 'node:assert/strict';
import { submitRow, fetchRows } from '../public/src/api.js';

const api = '/api';
const json = (data, status = 200) => Promise.resolve({ ok: status < 400, status, json: () => Promise.resolve(data) });

test('network failure resolves ok:false', async () => {
  const r = await submitRow({ response_id: 'a' }, { apiUrl: api, fetchImpl: () => Promise.reject(new Error('offline')) });
  assert.deepEqual(r, { ok: false });
});

test('posts JSON to /api/submit and passes duplicate through', async () => {
  let seenUrl, seen;
  const fetchImpl = (u, init) => { seenUrl = u; seen = init; return json({ ok: true, duplicate: true }); };
  const r = await submitRow({ response_id: 'a' }, { apiUrl: api, fetchImpl, hp: '' });
  assert.deepEqual(r, { ok: true, duplicate: true });
  assert.equal(seenUrl, '/api/submit');
  assert.equal(seen.method, 'POST');
  assert.match(seen.headers['Content-Type'], /application\/json/);
  assert.deepEqual(JSON.parse(seen.body), { row: { response_id: 'a' }, hp: '' });
});


test('demo mode stores locally when no api url', async () => {
  const mem = new Map();
  const storage = { getItem: k => mem.get(k) ?? null, setItem: (k, v) => mem.set(k, v), removeItem: k => mem.delete(k) };
  const r = await submitRow({ response_id: 'z' }, { apiUrl: '', storage });
  assert.deepEqual(r, { ok: true });
  assert.equal(JSON.parse(mem.get('demo_submissions'))[0].response_id, 'z');
});

test('fetchRows sends the key in a header, not the URL', async () => {
  let u, init;
  const fetchImpl = (x, i) => { u = x; init = i; return json({ rows: [{ a: 1 }] }); };
  assert.deepEqual(await fetchRows('a b&c', { apiUrl: api, fetchImpl }), [{ a: 1 }]);
  assert.equal(u, '/api/responses');
  assert.equal(init.headers['x-team-key'], encodeURIComponent('a b&c'));
});

test('fetchRows bad key throws bad_key', async () => {
  await assert.rejects(fetchRows('x', { apiUrl: api, fetchImpl: () => json({ error: 'bad_key' }, 401) }), /bad_key/);
});

test('server 4xx rejection is marked permanent (drop from retry queue)', async () => {
  assert.deepEqual(await submitRow({}, { apiUrl: api, fetchImpl: () => json({ ok: false, error: 'bad_value:q01' }, 400) }), { ok: false, permanent: true });
  assert.deepEqual(await submitRow({}, { apiUrl: api, fetchImpl: () => json({ ok: false, error: 'server' }, 500) }), { ok: false });
});

test('fetchRows surfaces not_configured and no_database', async () => {
  await assert.rejects(fetchRows('x', { apiUrl: api, fetchImpl: () => json({ error: 'not_configured' }, 503) }), /not_configured/);
});
