import test from 'node:test';
import assert from 'node:assert/strict';
import { filterRows, countSingle, countMulti, crosstab, gridSummary, funnel } from '../public/src/stats.js';
import { sampleRows } from '../public/src/sample.js';
import { validateRow } from '../public/src/server-validate.js';
import { buildSchema } from '../lib/schema.js';
import { toRow } from '../public/src/record.js';
import { FULL } from './fixtures.mjs';

const meta = { startedAt: 0, now: 1000, isTest: false };
const r1 = toRow({ answers: FULL, status: 'complete', responseId: '1', ...meta });
const r2 = toRow({ answers: { ...FULL, q1: 'maid', q18: ['job'], q6: 'monthly', q23: 'full' }, status: 'complete', responseId: '2', ...meta });
// rows read back from the Sheet are strings
const r3 = Object.fromEntries(Object.entries(toRow({ answers: { ...FULL, q18: ['job', 'debt'] }, status: 'complete', responseId: '3', ...meta, isTest: true })).map(([k, v]) => [k, String(v)]));
const s1 = toRow({ answers: { q1: 'other_job' }, status: 'screened_out', screenedAtQ: 1, responseId: '4', ...meta });
const rows = [r1, r2, r3, s1];

test('filterRows by status, test flag and occupation', () => {
  assert.equal(filterRows(rows, { includeTest: true, status: 'complete' }).length, 3);
  assert.equal(filterRows(rows, { includeTest: false, status: 'complete' }).length, 2);
  assert.equal(filterRows(rows, { includeTest: true, status: 'complete', occupation: 'รปภ.' }).length, 2);
});

test('countSingle gives all labels with n and pct summing ~100', () => {
  const c = countSingle(filterRows(rows, { includeTest: true, status: 'complete' }), 1);
  assert.equal(c.length, 4);
  assert.equal(c.find(x => x.label === 'รปภ.').n, 2);
  assert.ok(Math.abs(c.reduce((s, x) => s + x.pct, 0) - 100) < 0.01);
});

test('countMulti reads 1 and "1" flags', () => {
  const c = countMulti(filterRows(rows, { includeTest: true, status: 'complete' }), 18);
  assert.equal(c.find(x => x.label === 'ภาระหนี้').n, 2);
  assert.equal(c.find(x => x.label === 'ตกงานหรือถูกลดวันทำงาน').n, 2);
  assert.ok(Math.abs(c.find(x => x.label === 'ภาระหนี้').pct - 200 / 3) < 1e-9);
});

test('crosstab q6 x q23 dimensions', () => {
  const t = crosstab(filterRows(rows, { includeTest: true, status: 'complete' }), 6, 23);
  assert.equal(t.a.length, 4);
  assert.equal(t.b.length, 4);
  assert.equal(t.cells[0][2], 2); // รายวัน × ไม่ได้เลย
  assert.equal(t.cells[1][0], 1); // รายเดือน × ได้เต็ม
});

test('gridSummary counts per row', () => {
  const g = gridSummary(filterRows(rows, { includeTest: true, status: 'complete' }), 19);
  assert.equal(g.length, 4);
  assert.equal(g[0].counts['เคย'], 3);
});

test('funnel counts complete, screened per question and occupation', () => {
  const f = funnel(rows, { includeTest: true });
  assert.equal(f.complete, 3);
  assert.deepEqual(f.screened, { 1: 1, 2: 0, 3: 0, 4: 0 });
  assert.equal(f.byOccupation['รปภ.'], 2);
  assert.equal(f.byOccupation['แม่บ้านหรือพนักงานทำความสะอาด'], 1);
});

test('sampleRows is deterministic and valid', () => {
  const a = sampleRows(100, 1);
  assert.deepEqual(a, sampleRows(100, 1));
  assert.equal(a.length, 100);
  const schema = buildSchema();
  for (const r of a) assert.equal(validateRow(r, schema).ok, true);
  const screened = a.filter(r => r.status === 'screened_out').length;
  assert.ok(screened > 5 && screened < 40, `screened=${screened}`);
});
