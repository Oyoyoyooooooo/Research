import test from 'node:test';
import assert from 'node:assert/strict';
import { buildColumns, toRow, codebook, SYSTEM_COLUMNS, newResponseId } from '../public/src/record.js';
import { getQuestion } from '../public/src/questions.js';

import { FULL } from './fixtures.mjs';

const meta = { status: 'complete', startedAt: 1000, now: 61000, isTest: false, responseId: 'r1' };

test('columns start with system columns and are unique', () => {
  const keys = buildColumns().map(c => c.key);
  assert.deepEqual(keys.slice(0, 6), SYSTEM_COLUMNS);
  assert.equal(new Set(keys).size, keys.length);
  assert.equal(keys.filter(k => k.startsWith('q18_')).length, getQuestion('q18').options.length);
  assert.ok(keys.includes('q19_hosp') && keys.includes('q27_other_text') && keys.includes('q07'));
});

test('full row uses labels and flags', () => {
  const row = toRow({ answers: FULL, ...meta });
  assert.equal(row.q01, 'รปภ.');
  assert.equal(row.q18, 'ค่าเรียนหรือสุขภาพของลูก, ภาระหนี้');
  assert.equal(row.q18_child, 1);
  assert.equal(row.q18_debt, 1);
  assert.equal(row.q18_job, 0);
  assert.equal(row.q19_hosp, 'เคย');
  assert.equal(row.q27_other, 1);
  assert.equal(row.q27_other_text, 'ไม่มีเวลา');
  assert.equal(row.q33, FULL.q33);
  assert.equal(row.status, 'complete');
  assert.equal(row.duration_sec, 60);
  assert.equal(row.is_test, 0);
  assert.equal(row.screened_at_q, '');
  assert.equal(Object.keys(row).length, buildColumns().length);
});

test('q29 blank when q28 none', () => {
  const row = toRow({ answers: { ...FULL, q28: ['none'], q29: '5' }, ...meta });
  assert.equal(row.q29, '');
  assert.equal(row.q28_none, 1);
});

test('screened row is blank after screen point', () => {
  const row = toRow({ answers: { q1: 'maid', q2: 'gt45' }, ...meta, status: 'screened_out', screenedAtQ: 2 });
  assert.equal(row.status, 'screened_out');
  assert.equal(row.screened_at_q, 2);
  assert.equal(row.q02, 'มากกว่า 45 ปี');
  assert.equal(row.q05, '');
  assert.equal(row.q15_ucs, '');
});

test('codebook covers every question column', () => {
  const cb = codebook();
  assert.ok(cb.find(r => r.key === 'q24_ss33' && r.option.includes('มาตรา 33')));
  assert.equal(cb.length, buildColumns().length);
});

test('response id is unique-ish', () => {
  assert.notEqual(newResponseId(), newResponseId());
});
