import test from 'node:test';
import assert from 'node:assert/strict';
import { nextStep, prevId, progress, visibleQuestions } from '../public/src/flow.js';

test('screen-out at q1 and q2', () => {
  assert.deepEqual(nextStep('q1', { q1: 'other_job' }), { type: 'screened', atQ: 1 });
  assert.deepEqual(nextStep('q2', { q2: 'gt45' }), { type: 'screened', atQ: 2 });
  assert.deepEqual(nextStep('q2', { q2: '30_35' }), { type: 'question', id: 'q3' });
  assert.deepEqual(nextStep('q4', { q4: 'no' }), { type: 'screened', atQ: 4 });
});

test('last question leads to done', () => {
  assert.deepEqual(nextStep('q33', {}), { type: 'done' });
});

test('q28 none skips q29 both ways', () => {
  const a = { q28: ['none'] };
  assert.deepEqual(nextStep('q28', a), { type: 'question', id: 'q30' });
  assert.equal(prevId('q30', a), 'q28');
  assert.deepEqual(nextStep('q28', { q28: ['a'] }), { type: 'question', id: 'q29' });
  assert.equal(prevId('q1', {}), null);
});

test('progress counts visible questions', () => {
  assert.deepEqual(progress('q1', {}), { index: 1, total: 33 });
  assert.deepEqual(progress('q30', { q28: ['none'] }), { index: 29, total: 32 });
  assert.equal(visibleQuestions({ q28: ['none'] }).length, 32);
});

import { firstProblem } from '../public/src/flow.js';
import { FULL } from './fixtures.mjs';

test('firstProblem: complete answers have none', () => {
  assert.equal(firstProblem(FULL), null);
});

test('firstProblem: screen-out answer later changed via back is caught', () => {
  assert.deepEqual(firstProblem({ ...FULL, q2: 'lt30' }), { type: 'screened', id: 'q2' });
});

test('firstProblem: missing or emptied required answer is caught', () => {
  const a = { ...FULL, q18: [] };
  assert.deepEqual(firstProblem(a), { type: 'missing', id: 'q18' });
  const b = { ...FULL }; delete b.q7;
  assert.deepEqual(firstProblem(b), { type: 'missing', id: 'q7' });
});

test('firstProblem: q29 not required when hidden', () => {
  const a = { ...FULL, q28: ['none'] }; delete a.q29;
  assert.equal(firstProblem(a), null);
});
