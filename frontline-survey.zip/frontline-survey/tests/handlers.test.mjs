import test from 'node:test';
import assert from 'node:assert/strict';
import { handleSubmit, handleList, bangkokIso } from '../lib/handlers.js';
import { toRow } from '../public/src/record.js';
import { FULL } from './fixtures.mjs';

function memStore() {
  const rows = [];
  return {
    rows,
    insert: async r => (rows.some(x => x.response_id === r.response_id) ? 'duplicate' : (rows.push(r), 'inserted')),
    list: async () => rows,
  };
}
const NOW = new Date('2026-11-14T03:04:05Z');
const goodRow = () => toRow({ answers: FULL, status: 'complete', startedAt: 0, now: 60000, isTest: false, responseId: 'abc-123' });
const body = (row, hp = '') => JSON.stringify({ row, hp });

test('bangkokIso formats +07:00', () => {
  assert.equal(bangkokIso(NOW), '2026-11-14T10:04:05+07:00');
});

test('valid row is stored with server time', async () => {
  const store = memStore();
  const r = await handleSubmit(body(goodRow()), { store, now: NOW });
  assert.deepEqual(r, { status: 200, body: { ok: true } });
  assert.equal(store.rows[0].submitted_at, '2026-11-14T10:04:05+07:00');
  assert.equal(store.rows[0].q01, 'รปภ.');
});

test('duplicate id is not stored twice', async () => {
  const store = memStore();
  await handleSubmit(body(goodRow()), { store, now: NOW });
  const r = await handleSubmit(body(goodRow()), { store, now: NOW });
  assert.deepEqual(r, { status: 200, body: { ok: true, duplicate: true } });
  assert.equal(store.rows.length, 1);
});

test('honeypot looks successful but stores nothing', async () => {
  const store = memStore();
  const r = await handleSubmit(body(goodRow(), 'http://spam'), { store, now: NOW });
  assert.deepEqual(r, { status: 200, body: { ok: true } });
  assert.equal(store.rows.length, 0);
});

test('bad json, wrong shape, invalid label and oversized body', async () => {
  const store = memStore();
  assert.deepEqual(await handleSubmit('{not json', { store, now: NOW }), { status: 400, body: { ok: false, error: 'bad_json' } });
  assert.deepEqual(await handleSubmit('null', { store, now: NOW }), { status: 400, body: { ok: false, error: 'bad_json' } });
  const bad = await handleSubmit(body({ ...goodRow(), q01: 'ผู้จัดการ' }), { store, now: NOW });
  assert.equal(bad.status, 400);
  assert.equal(bad.body.ok, false);
  const big = await handleSubmit('x'.repeat(20 * 1024 + 1), { store, now: NOW });
  assert.deepEqual(big, { status: 413, body: { ok: false, error: 'too_large' } });
  assert.equal(store.rows.length, 0);
});

test('store failure returns 500 json without details', async () => {
  const store = { insert: async () => { throw new Error('db down secret'); } };
  const r = await handleSubmit(body(goodRow()), { store, now: NOW });
  assert.deepEqual(r, { status: 500, body: { ok: false, error: 'server' } });
});

test('list requires the right team key', async () => {
  const store = memStore();
  await handleSubmit(body(goodRow()), { store, now: NOW });
  const ok = await handleList({ 'x-team-key': 'secret' }, { store, teamKey: 'secret' });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.rows.length, 1);
  assert.deepEqual(await handleList({ 'x-team-key': 'nope' }, { store, teamKey: 'secret' }), { status: 401, body: { error: 'bad_key' } });
  assert.deepEqual(await handleList({}, { store, teamKey: 'secret' }), { status: 401, body: { error: 'bad_key' } });
});

test('list says not_configured when TEAM_KEY is missing (never matches empty)', async () => {
  const store = memStore();
  assert.deepEqual(await handleList({ 'x-team-key': '' }, { store, teamKey: '' }), { status: 503, body: { error: 'not_configured' } });
  assert.deepEqual(await handleList({}, { store, teamKey: undefined }), { status: 503, body: { error: 'not_configured' } });
});

test('Thai team key works when the client URI-encodes it; server trims env value', async () => {
  const store = memStore();
  const key = 'ทีมเรา-2026-ห้ามบอกใคร-7319';
  const ok = await handleList({ 'x-team-key': encodeURIComponent(key) }, { store, teamKey: key + '\n' });
  assert.equal(ok.status, 200);
  const bad = await handleList({ 'x-team-key': '%E0%A' }, { store, teamKey: key });
  assert.deepEqual(bad, { status: 401, body: { error: 'bad_key' } });
});

test('no database configured → 503 no_database on both routes', async () => {
  assert.deepEqual(await handleSubmit(body(goodRow()), { store: null, now: NOW }), { status: 503, body: { ok: false, error: 'no_database' } });
  assert.deepEqual(await handleList({ 'x-team-key': 'k' }, { store: null, teamKey: 'k' }), { status: 503, body: { error: 'no_database' } });
});

test('list store failure returns 500 json', async () => {
  const store = { list: async () => { throw new Error('boom'); } };
  assert.deepEqual(await handleList({ 'x-team-key': 'k' }, { store, teamKey: 'k' }), { status: 500, body: { error: 'server' } });
});
